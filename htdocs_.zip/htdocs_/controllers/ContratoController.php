<?php
// controllers/ContratoController.php

require_once __DIR__ . '/../config/db.php';

class ContratoController
{
    /**
     * ID do módulo "Material" no banco de dados.
     * Tabela: modulos
     */
    private const MODULO_ID = 61;

    public function index()
    {
        if (!AuthManager::validateSession()) {
            header('Location: ' . BASE_PATH . '/login');
            exit;
        }

        $pageTitle = "Gestão de Contratos";
        $pageScripts = ['dist/js/contrato-search.js'];
        $moduloId = self::MODULO_ID;

        ob_start();
        require_once __DIR__ . '/../views/contrato/index.php'; // View da lista
        $content = ob_get_clean();

        require_once __DIR__ . '/../views/layout.php';
    }

    // NOVO MÉTODO
    public function create()
    {
        if (!AuthManager::validateSession()) {
            header('Location: ' . BASE_PATH . '/login');
            exit;
        }

        $pageTitle = "Novo Contrato";
        // Esta linha carrega o JavaScript que faz os modais e o select2 funcionarem
        $pageScripts = ['plugins/select2/js/select2.full.min.js', 'dist/js/contrato-form.js'];

        $isEditing = false;
        $contrato = null;
        $equipes_contrato = [];

        // Estas linhas buscam os dados para preencher os dropdowns
        $formData = self::getFormData(null);
        $empresas = $formData['empresas'];
        $servicos = $formData['servicos'];
        $setores = $formData['setores'];
        $tipo_equipes = $formData['tipo_equipes'];

        ob_start();
        require_once __DIR__ . '/../views/contrato/form.php';
        $content = ob_get_clean();

        require_once __DIR__ . '/../views/layout.php';
    }

    // NOVO MÉTODO
    public function edit($id)
    {
        if (!AuthManager::validateSession()) {
            header('Location: ' . BASE_PATH . '/login');
            exit;
        }

        $pageTitle = "Editar Contrato";
        $pageScripts = ['plugins/select2/js/select2.full.min.js', 'dist/js/contrato-form.js'];
        $isEditing = true;
        $contratoId = (int)$id;

        // Busca todos os dados necessários
        $formData = self::getFormData($contratoId);

        // --- AQUI ESTÁ A CORREÇÃO FINAL ---
        // Nós estávamos a esquecer de "desempacotar" as listas para a view.
        $contrato = $formData['contrato'];
        $equipes_contrato = $formData['equipes_contrato'];
        $empresas = $formData['empresas'];
        $servicos = $formData['servicos'];
        $setores = $formData['setores'];
        $tipo_equipes = $formData['tipo_equipes'];
        // --- FIM DA CORREÇÃO ---

        ob_start();
        require_once __DIR__ . '/../views/contrato/form.php';
        $content = ob_get_clean();

        require_once __DIR__ . '/../views/layout.php';
    }

    // NOVO MÉTODO
    public function store()
    {
        if (!AuthManager::validateSession()) {
            exit;
        }

        $userId = $_SESSION['user_id'];
        $contratoId = $_POST['id'] ?? $_POST['id_contrato'] ?? null;
        $isEdit = !empty($contratoId);
        $permissaoNecessaria = $isEdit ? 'editar' : 'criar';

        if (!PermissionManager::can($permissaoNecessaria, self::MODULO_ID)) {
            header('Location: ' . BASE_PATH . '/contratos?status=no_permission');
            exit;
        }

        try {
            $pdo = getDbConnection();
            $pdo->beginTransaction();
            $action = $_POST['action'] ?? '';

            switch ($action) {
                case 'salvarDadosGerais':
                    $contratoId = self::salvarDadosGerais($pdo, $_POST, $userId);
                    break;
                case 'salvarEquipes':
                    $contratoId = (int)$_POST['id_contrato'];
                    $equipes = $_POST['equipes'] ?? [];
                    self::atualizarEquipes($pdo, $contratoId, $equipes, $userId);
                    break;
                default:
                    throw new Exception("Ação inválida.");
            }

            $pdo->commit();
            header('Location: ' . BASE_PATH . '/contratos/editar/' . $contratoId . '?status=success');
            exit;
        } catch (Exception $e) {
            if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
            error_log("Erro no ContratoController->store(): " . $e->getMessage());
            $redirectUrl = $contratoId ? '/contratos/editar/' . $contratoId : '/contratos/novo';
            header("Location: " . BASE_PATH . $redirectUrl . '?status=error&msg=' . urlencode($e->getMessage()));
            exit;
        }
    }

    // NOVO MÉTODO
    public function delete($id)
    {
        if (!AuthManager::validateSession()) {
            exit;
        }

        if (self::deleteContrato((int)$id)) {
            header('Location: ' . BASE_PATH . '/contratos?status=deleted');
        } else {
            header('Location: ' . BASE_PATH . '/contratos?status=no_permission');
        }
        exit;
    }

    // NOVO MÉTODO
    public function search()
    {
        if (!AuthManager::validateSession()) {
            http_response_code(403);
            exit('Acesso negado.');
        }

        $search = $_GET['search'] ?? '';
        $contratos = self::getContratos($search);

        $canEdit = PermissionManager::can('editar', self::MODULO_ID);
        $canDelete = PermissionManager::can('excluir', self::MODULO_ID);

        if (empty($contratos)) {
            echo '<tr><td colspan="7" class="text-center text-muted">Nenhum contrato encontrado.</td></tr>';
            exit;
        }

        foreach ($contratos as $contrato) {
            $ativoBadge = $contrato['ativo'] == 's' ? '<span class="badge badge-success">Sim</span>' : '<span class="badge badge-danger">Não</span>';
            $dataInicio = $contrato['prazo_inicio'] ? date('d/m/Y', strtotime($contrato['prazo_inicio'])) : 'N/D';
            $dataFim = $contrato['prazo_fim'] ? date('d/m/Y', strtotime($contrato['prazo_fim'])) : 'N/D';

            echo "<tr>
                    <td>" . htmlspecialchars($contrato['empresa_nome']) . "</td>
                    <td>" . $ativoBadge . "</td>
                    <td>" . htmlspecialchars($contrato['servico_nome']) . "</td>
                    <td>" . $dataInicio . "</td>
                    <td>" . $dataFim . "</td>
                    <td>" . htmlspecialchars($contrato['contrato']) . "</td>
                    <td><div class='btn-group btn-group-sm'>";
            if ($canEdit) {
                echo "<a href='" . BASE_PATH . "/contratos/editar/{$contrato['id']}' class='btn btn-primary'><i class='fas fa-edit'></i></a>";
            }
            if ($canDelete) {
                echo "<a href='" . BASE_PATH . "/contratos/excluir/{$contrato['id']}' class='btn btn-danger' onclick=\"return confirm('Tem certeza?')\"><i class='fas fa-trash'></i></a>";
            }
            echo "</div></td></tr>";
        }
    }

    /**
     * Ponto de entrada que roteia a ação com base no formulário enviado.
     */
    public static function handleRequest(array $postData, int $userId)
    {
        //session_start();
        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) {
            header('Location: ../public/login.php');
            exit;
        }

        // ---> INÍCIO DA ADIÇÃO DA GUARITA DE SEGURANÇA <---

        // 1. Determinar se é uma edição (tem um ID) ou uma criação (não tem ID)
        $isEdit = !empty($postData['id']);
        $permissaoNecessaria = $isEdit ? 'editar' : 'criar';

        // 2. Chamar o PermissionManager para verificar a permissão
        if (!PermissionManager::can($permissaoNecessaria, self::MODULO_ID)) {
            // 3. Se não tiver permissão, redireciona com uma mensagem de erro e termina a execução.
            header('Location: ../public/material.php?status=no_permission');
            exit;
        }

        // Se não for um POST, não faz nada
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return;
        }

        $action = $postData['action'] ?? '';
        $pdo = getDbConnection();

        try {
            $pdo->beginTransaction();
            $contratoId = null;

            switch ($action) {
                case 'salvarDadosGerais':
                    $contratoId = self::salvarDadosGerais($pdo, $postData, $userId);
                    break;

                case 'salvarEquipes':
                    $contratoId = (int)$postData['id_contrato'];
                    $equipes = $postData['equipes'] ?? [];
                    self::atualizarEquipes($pdo, $contratoId, $equipes, $userId);
                    break;

                default:
                    // Se a ação não for reconhecida, não faz nada
                    $pdo->rollBack();
                    return;
            }

            $pdo->commit();
            header('Location: ../public/contrato.php?view=form&id=' . $contratoId . '&status=success');
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log("Erro ao salvar contrato: " . $e->getMessage());
            $view = !empty($contratoId) ? 'form&id=' . $contratoId : 'form';
            header('Location: ../public/contrato.php?view=' . $view . '&status=error');
        }
        exit;
    }

    /**
     * Salva ou atualiza os dados principais do contrato.
     * Retorna o ID do contrato salvo.
     */
    private static function salvarDadosGerais($pdo, array $postData, int $userId): int
    {
        $id = !empty($postData['id']) ? (int)$postData['id'] : null;

        $params = [
            'id_empresa' => (int)$postData['id_empresa'],
            'id_servico' => (int)$postData['id_servico'],
            'id_setor' => (int)$postData['id_setor'],
            'numero_orcamento' => trim($postData['numero_orcamento']),
            'contrato' => trim($postData['contrato']),
            'prazo_inicio' => !empty($postData['prazo_inicio']) ? $postData['prazo_inicio'] : null,
            'prazo_fim' => !empty($postData['prazo_fim']) ? $postData['prazo_fim'] : null,
            'ativo' => $postData['ativo'] ?? 's',
            'user_id' => $userId
        ];

        if ($id) {
            // ATUALIZAR
            $sql = "UPDATE contrato SET 
                        id_empresa = :id_empresa, id_servico = :id_servico, id_setor = :id_setor, 
                        numero_orcamento = :numero_orcamento, contrato = :contrato, prazo_inicio = :prazo_inicio, 
                        prazo_fim = :prazo_fim, ativo = :ativo, ultima_alteracao_por = :user_id 
                    WHERE id = :id";
            $params['id'] = $id;
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            return $id;
        } else {
            // INSERIR
            $sql = "INSERT INTO contrato 
                        (id_empresa, id_servico, id_setor, numero_orcamento, contrato, prazo_inicio, prazo_fim, ativo, criado_por) 
                    VALUES 
                        (:id_empresa, :id_servico, :id_setor, :numero_orcamento, :contrato, :prazo_inicio, :prazo_fim, :ativo, :user_id)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            return $pdo->lastInsertId();
        }
    }

    /**
     * Atualiza a composição de equipes de um contrato. (Método original reutilizado)
     */
    private static function atualizarEquipes($pdo, int $contratoId, array $equipes, int $userId)
    {
        // Limpa as equipes antigas
        $stmtDelete = $pdo->prepare("DELETE FROM contrato_equipes WHERE id_contrato = ?");
        $stmtDelete->execute([$contratoId]);

        // Insere as novas equipes
        if (!empty($equipes)) {
            $stmtInsert = $pdo->prepare(
                "INSERT INTO contrato_equipes (id_contrato, id_tipo_equipe, quantidade, descricao, valor_equipe, criado_por) VALUES (:id_contrato, :id_tipo_equipe, :quantidade, :descricao, :valor_equipe, :criado_por)"
            );
            foreach ($equipes as $equipe) {
                if (!empty($equipe['id_tipo_equipe']) && !empty($equipe['quantidade'])) {
                    $stmtInsert->execute([
                        ':id_contrato' => $contratoId,
                        ':id_tipo_equipe' => (int)$equipe['id_tipo_equipe'],
                        ':quantidade' => (int)$equipe['quantidade'],
                        ':descricao' => trim($equipe['descricao']),
                        ':valor_equipe' => !empty($equipe['valor']) ? (float)$equipe['valor'] : null,
                        ':criado_por' => $userId
                    ]);
                }
            }
        }
    }

    /**
     * Busca contratos para a tela de listagem.
     */
    public static function getContratos(string $search = '')
    {
        $pdo = getDbConnection();
        $sql = "SELECT c.id, c.contrato, c.prazo_inicio, c.prazo_fim, c.ativo, e.nome_fantasia as empresa_nome, s.nome as servico_nome
                FROM contrato c
                JOIN empresas e ON c.id_empresa = e.id
                JOIN servicos s ON c.id_servico = s.id";

        $params = [];
        if (!empty($search)) {
            $sql .= " WHERE c.contrato LIKE ? OR e.nome_fantasia LIKE ?";
            $searchTerm = '%' . $search . '%';
            $params = [$searchTerm, $searchTerm];
        }
        $sql .= " ORDER BY c.data_cadastro DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Busca todos os dados necessários para o formulário de contrato.
     */
    public static function getFormData(?int $contratoId = null)
    {
        $pdo = getDbConnection();
        $data = [
            'contrato' => null,
            'equipes_contrato' => [],
            'empresas' => [],
            'servicos' => [],
            'setores' => [],
            'tipo_equipes' => []
        ];

        // Busca dados para os selects
        $data['empresas'] = $pdo->query("SELECT id, nome_fantasia FROM empresas ORDER BY nome_fantasia ASC")->fetchAll(PDO::FETCH_ASSOC);
        $data['servicos'] = $pdo->query("SELECT id, nome FROM servicos WHERE ativo = 's' ORDER BY nome ASC")->fetchAll(PDO::FETCH_ASSOC);
        $data['setores'] = $pdo->query("SELECT id, setor FROM setor ORDER BY setor ASC")->fetchAll(PDO::FETCH_ASSOC);
        $data['tipo_equipes'] = $pdo->query("SELECT id, tipo_equipe FROM tipo_equipes ORDER BY tipo_equipe ASC")->fetchAll(PDO::FETCH_ASSOC);

        if ($contratoId) {
            $stmt = $pdo->prepare("SELECT * FROM contrato WHERE id = ?");
            $stmt->execute([$contratoId]);
            $data['contrato'] = $stmt->fetch(PDO::FETCH_ASSOC);

            $stmtEquipes = $pdo->prepare("SELECT * FROM contrato_equipes WHERE id_contrato = ?");
            $stmtEquipes->execute([$contratoId]);
            $data['equipes_contrato'] = $stmtEquipes->fetchAll(PDO::FETCH_ASSOC);
        }
        return $data;
    }

    /**
     * Deleta um contrato.
     */
    public static function deleteContrato(int $id)
    {
        if (!PermissionManager::can('excluir', self::MODULO_ID)) {
            // Retorna falso para indicar que a operação não foi permitida
            return false;
        }

        try {
            $pdo = getDbConnection();
            $stmt = $pdo->prepare("DELETE FROM contrato WHERE id = ?");
            $stmt->execute([$id]); // A exclusão em cascata cuidará das equipes
            return true;
        } catch (PDOException $e) {
            error_log("Erro ao excluir contrato: " . $e->getMessage());
            return false;
        }
    }
}
