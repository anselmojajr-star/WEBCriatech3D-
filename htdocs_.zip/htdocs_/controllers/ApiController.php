<?php
// controllers/ApiController.php (VERSÃO CORRETA E ATUALIZADA)

// ===== LINHAS DE DEPURAÇÃO - VÃO FORÇAR O ERRO REAL A APARECER =====
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// =================================================================

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../security/AuthManager.php';

class ApiController
{
    /**
     * Lida com requisições de salvamento para entidades, de forma dinâmica.
     *
     * @param string $tableName O nome da tabela do banco de dados (ex: 'perfil').
     * @param array $fieldMapping Um array associativo que mapeia [coluna_db => chave_input] (ex: ['perfil' => 'perfil_nome']).
     * @param string|null $uniqueCheckInputKey A chave do input a ser usada para verificar duplicidade (geralmente o campo de nome/texto).
     */
    public static function handleDynamicSave(string $tableName, array $fieldMapping, ?string $uniqueCheckInputKey = null)
    {
        // Define o cabeçalho da resposta como JSON
        header('Content-Type: application/json');

        // 1. Validação de Sessão
        if (session_status() == PHP_SESSION_NONE) session_start();
        if (empty($_SESSION['user_id'])) {
            http_response_code(401); // Não autorizado
            echo json_encode(['success' => false, 'message' => 'Acesso não autorizado.']);
            exit;
        }

        // 2. Pega o input (funciona para JSON e POST)
        $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

        $params = [];
        $columns = [];
        $placeholders = [];

        // 3. Valida e prepara os dados com base no mapeamento
        foreach ($fieldMapping as $dbColumn => $inputKey) {
            $value = trim($data[$inputKey] ?? '');
            if (empty($value)) {
                http_response_code(400); // Requisição inválida
                echo json_encode(['success' => false, 'message' => "O campo {$inputKey} é obrigatório."]);
                exit;
            }
            $params[$dbColumn] = $value;
            $columns[] = $dbColumn;
            $placeholders[] = ":{$dbColumn}";
        }

        try {
            $pdo = getDbConnection();

            // 4. Verifica se já existe (se uma chave de verificação foi fornecida)
            if ($uniqueCheckInputKey && isset($data[$uniqueCheckInputKey])) {
                // Descobre a coluna correta do DB para a verificação de duplicidade
                $uniqueCheckDbColumn = array_search($uniqueCheckInputKey, $fieldMapping);
                if ($uniqueCheckDbColumn) {
                    $stmtCheck = $pdo->prepare("SELECT id FROM {$tableName} WHERE {$uniqueCheckDbColumn} LIKE ?");
                    $stmtCheck->execute([$data[$uniqueCheckInputKey]]);
                    if ($stmtCheck->fetch()) {
                        http_response_code(409); // Conflito
                        echo json_encode(['success' => false, 'message' => 'Este item já está cadastrado.']);
                        exit;
                    }
                }
            }

            // 5. Insere no banco
            $sql = sprintf(
                "INSERT INTO %s (%s) VALUES (%s)",
                $tableName,
                implode(', ', $columns),
                implode(', ', $placeholders)
            );

            $stmtInsert = $pdo->prepare($sql);
            $stmtInsert->execute($params);
            $newId = $pdo->lastInsertId();

            // 6. Retorna sucesso
            echo json_encode(['success' => true, 'id' => $newId] + $params);
        } catch (PDOException $e) {
            http_response_code(500); // Erro interno do servidor
            error_log("Erro em handleDynamicSave para a tabela {$tableName}: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor.']);
        }
    }

    /**
     * Lida com a requisição de login vinda do aplicativo móvel.
     */
    public function loginApp()
    {
        // Define o cabeçalho da resposta como JSON
        header('Content-Type: application/json');

        // Lê os dados POST da forma mais compatível
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';

        // Chama a lógica de autenticação e geração de token no AuthManager
        $result = AuthManager::loginApp($username, $password);

        // Define o código de status HTTP com base no sucesso
        if (isset($result['success']) && $result['success']) {
            http_response_code(200);
        } else {
            http_response_code(401); // Não autorizado
        }

        // Envia a resposta JSON de volta para o aplicativo
        echo json_encode($result);
        exit;
    }


    /**
     * Busca os projetos associados a um usuário autenticado via token.
     * Esta é a única função que o seu app deve usar para obter a lista de projetos.
     */
    public function getProjetosApp()
    {
        header('Access-Control-Allow-Origin: *');
        header('Content-Type: application/json; charset=UTF-8');

        try {
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido ou expirado.']);
                return;
            }

            $pdo = getDbConnection();

            // ===== CONSULTA SQL FINAL E 100% CORRIGIDA =====
            $sql = "
                SELECT DISTINCT
                    p.id,
                    p.nome_projeto,
                    p.data_inicio,
                    p.data_fim,
                    c.contrato AS numero_contrato,
                    e.nome_fantasia AS nome_empresa
                FROM projeto p
                JOIN contrato c ON p.id_contrato = c.id
                JOIN empresas e ON c.id_empresa = e.id
                LEFT JOIN projeto_lideres pl ON p.id = pl.id_projeto
                LEFT JOIN projeto_equipes pe ON p.id = pe.id_projeto
                LEFT JOIN equipe_membros em ON pe.id_equipe = em.id_equipe
                WHERE 
                    (pl.id_usuario_lider = :userIdLider OR em.id_usuario = :userIdMembro) -- 1. PARÂMETROS ÚNICOS
                ORDER BY p.data_cadastro DESC
            ";

            $stmt = $pdo->prepare($sql);

            // 2. VALORES CORRESPONDENTES PARA OS PARÂMETROS ÚNICOS
            $stmt->execute([
                'userIdLider' => $userId,
                'userIdMembro' => $userId
            ]);

            $projetos = $stmt->fetchAll(PDO::FETCH_ASSOC);

            http_response_code(200);
            echo json_encode(['success' => true, 'projetos' => $projetos]);
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL FINAL em getProjetosApp: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao processar sua requisição.']);
        }
    }


    public function getProjetos()
    {
        // Valida o Token JWT e obtém os dados do usuário
        $userData = AuthManager::validateToken(); // Usaremos um AuthManager atualizado
        if (!$userData) {
            http_response_code(401);
            echo json_encode(['success' => false, 'message' => 'Token inválido ou expirado.']);
            exit;
        }

        try {
            // Conecta-se ao banco de dados do cliente (tenant)
            $pdo = getDbConnection();

            $userId = $userData['id'];

            // Consulta SQL para buscar os projetos atribuídos ao usuário (seja como líder ou membro de equipa)
            $sql = "
            SELECT DISTINCT
                p.id,
                p.nome_projeto,
                p.data_inicio,
                p.data_fim,
                c.contrato AS numero_contrato,      -- CORREÇÃO 1
                e.nome_fantasia AS nome_empresa    -- CORREÇÃO 2
            FROM projeto p
            JOIN contrato c ON p.id_contrato = c.id
            JOIN empresas e ON c.id_empresa = e.id
            LEFT JOIN projeto_lideres pl ON p.id = pl.id_projeto
            LEFT JOIN projeto_equipes pe ON p.id = pe.id_projeto
            LEFT JOIN equipe_membros em ON pe.id_equipe = em.id_equipe
            WHERE 
                p.ativo = '1' AND (pl.id_usuario_lider = :userId OR em.id_usuario = :userId) -- CORREÇÃO 3
            ORDER BY p.data_cadastro DESC
        ";

            $stmt = $pdo->prepare($sql);
            $stmt->execute(['userId' => $userId]);
            $projetos = $stmt->fetchAll(PDO::FETCH_ASSOC);

            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'projetos' => $projetos]);
        } catch (Exception $e) {
            http_response_code(500);
            header('Content-Type: application/json');
            error_log("Erro em ApiController->getProjetos: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno ao buscar projetos.']);
        }
        exit;
    }

    /**
     * Busca os marcadores (componentes/OSs) de um projeto específico.
     * Corresponde ao endpoint: GET /projects/{id}/markers
     */
    public function getProjectMarkers($projectId)
    {
        error_log("--- DIAGNÓSTICO getProjectMarkers INICIADO ---");
        error_log("ID do Projeto recebido: " . $projectId);
        error_log("Cabeçalho Authorization: " . ($_SERVER['HTTP_AUTHORIZATION'] ?? 'NÃO EXISTE'));
        error_log("--- FIM DO DIAGNÓSTICO ---");

        header('Access-Control-Allow-Origin: *');
        header('Content-Type: application/json; charset=UTF-8');

        try {
            // 1. Valida o token do utilizador.
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) { // Verificamos se o token é válido
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido ou expirado.']);
                return;
            }

            // -> error_log("DEBUG getProjectMarkers: User ID = " . $userId);

            // 2. Verifica se o ID do projeto foi realmente passado pela URL.
            if (empty($projectId)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'ID do projeto não fornecido.']);
                return;
            }

            $pdo = getDbConnection();

            $statusFilterSql = "";
            $params = ['projectId' => $projectId]; // Parâmetros iniciais

            // Verifica se o usuário tem o perfil 'equipe' (ID 6 no seu dump SQL)
            $stmtProfile = $pdo->prepare("SELECT COUNT(*) FROM loginperfil WHERE id_login = :userId AND id_perfil = 6"); // ID 6 = 'equipe'
            $stmtProfile->execute(['userId' => $userId]);
            $isFieldTeam = (bool) $stmtProfile->fetchColumn();
            // -> error_log("DEBUG getProjectMarkers: isFieldTeam = " . ($isFieldTeam ? 'true' : 'false'));

            if ($isFieldTeam) {
                // Se for equipe de campo, adiciona o filtro de status
                // Filtra por Laranja ('em_andamento') e Amarelo ('em_execucao')
                $statusFilterSql = " AND status IN (:status1, :status2) ";
                $params['status1'] = 'em_andamento'; // Laranja - Liberado
                $params['status2'] = 'em_execucao';  // Amarelo - Em execução (conforme sua legenda)
                // -> error_log("DEBUG getProjectMarkers: Aplicando filtro de status para equipe.");
            }

            // 3. Consulta SQL para buscar os marcadores daquele projeto.
            $sql = "
                SELECT 
                    id,
                    latitude,
                    longitude,
                    status,
                    descricao_local
                FROM projeto_componentes
                WHERE id_projeto = :projectId
            " . $statusFilterSql;

            // -> error_log("DEBUG getProjectMarkers: SQL Query = " . $sql); // Log a query FINAL
            // -> error_log("DEBUG getProjectMarkers: Params = " . print_r($params, true)); // Log os parâmetros

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            //$stmt->execute(['projectId' => $projectId]);
            $markers = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // -> error_log("DEBUG getProjectMarkers: Marcadores encontrados no DB = " . count($markers)); // Log quantos foram encontrados
            // -> error_log("DEBUG getProjectMarkers: Dados dos Marcadores = " . print_r($markers, true)); // Log OS DADOS REAIS ANTES DE ENVIAR

            // 4. Retorna a lista de marcadores em formato JSON.
            http_response_code(200);
            echo json_encode(['success' => true, 'markers' => $markers]);
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em getProjectMarkers: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao buscar os marcadores.']);
        }
    }

    /**
     * Altera o status de uma Ordem de Serviço (componente) para 'em_andamento'.
     */
    public function liberarOS($osId)
    {
        header('Access-Control-Allow-Origin: *');
        header('Content-Type: application/json; charset=UTF-8');

        try {
            // Segurança: Valida o token para garantir que o utilizador está autenticado
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido ou expirado.']);
                return;
            }

            if (empty($osId)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'ID da OS não fornecido.']);
                return;
            }

            $pdo = getDbConnection();

            // Prepara e executa a atualização no banco de dados
            $sql = "UPDATE projeto_componentes SET status = 'em_andamento' WHERE id = :osId AND status = 'planejado'";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['osId' => $osId]);

            // Verifica se alguma linha foi realmente alterada
            if ($stmt->rowCount() > 0) {

                $logMessage = "OS liberada para execução via App";
                // Passamos 'planejado' como status anterior e 'em_andamento' como novo
                self::logComponenteActivity($osId, $userId, null, 'OS_LIBERADA_APP', $logMessage, null, null, 'planejado', 'em_andamento');

                http_response_code(200);
                echo json_encode(['success' => true, 'message' => 'OS #' . $osId . ' liberada com sucesso.']);
            } else {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'OS não encontrada ou já estava liberada.']);
            }
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em liberarOS: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor.']);
        }
    }

    /**
     * Busca os detalhes completos de uma Ordem de Serviço (componente).
     */
    public function getOSDetails($osId)
    {
        header('Access-Control-Allow-Origin: *');
        header('Content-Type: application/json; charset=UTF-8');

        try {
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido.']);
                return;
            }
            if (empty($osId)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'ID da OS não fornecido.']);
                return;
            }

            $pdo = getDbConnection();
            $response = [];

            // 1. Buscar Dados Gerais da OS
            $stmtGeral = $pdo->prepare("SELECT id, status, descricao_local, latitude, longitude, id_projeto FROM projeto_componentes WHERE id = :osId");
            $stmtGeral->execute(['osId' => $osId]);
            $osGeralData = $stmtGeral->fetch(PDO::FETCH_ASSOC);
            $response['geral'] = $osGeralData;

            // Se não encontrou a OS, pare aqui
            if (!$osGeralData) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'OS não encontrada.']);
                return;
            }

            // 2. Buscar Materiais (Plano - Macro)
            // ... (código da busca de materiais sem mudança) ...
            $sqlMateriais = "
                SELECT
                    ce.id AS compItemId, 'estrutura' AS itemType, e.nome AS nome,
                    ce.quantidade, 'UN' AS unidade
                FROM componente_estruturas ce JOIN estruturas e ON ce.id_estrutura = e.id
                WHERE ce.id_componente = :osId1
                UNION ALL
                SELECT
                    cma.id AS compItemId, 'material' AS itemType, m.material AS nome,
                    cma.quantidade, med.unidade
                FROM componente_materiais_avulsos cma
                JOIN p_material m ON cma.id_material = m.id
                JOIN medidas med ON m.id_medida = med.id
                WHERE cma.id_componente = :osId2
            ";
            $stmtMateriais = $pdo->prepare($sqlMateriais);
            $stmtMateriais->bindValue(':osId1', $osId, PDO::PARAM_INT);
            $stmtMateriais->bindValue(':osId2', $osId, PDO::PARAM_INT);
            $stmtMateriais->execute();
            $response['materiais'] = $stmtMateriais->fetchAll(PDO::FETCH_ASSOC);

            // 3. Buscar Fotos
            // ... (código da busca de fotos sem mudança) ...
            $stmtFotos = $pdo->prepare("SELECT id, caminho_arquivo, descricao, timestamp_upload, type FROM os_photos WHERE id_os_componente = :osId ORDER BY timestamp_upload DESC");
            $stmtFotos->execute(['osId' => $osId]);
            $response['fotos'] = $stmtFotos->fetchAll(PDO::FETCH_ASSOC);


            // 4. Buscar Histórico
            // ... (código da busca de histórico sem mudança) ...
            $sqlHistorico = "SELECT
                                cal.id, cal.timestamp_acao, cal.tipo_acao, cal.observacao,
                                u.username as usuario_acao
                           FROM componente_atividades_log cal
                           JOIN usuarios u ON cal.id_usuario = u.id
                           WHERE cal.id_componente = :osId
                           ORDER BY cal.timestamp_acao DESC
                           LIMIT 50";
            $stmtHistorico = $pdo->prepare($sqlHistorico);
            $stmtHistorico->execute(['osId' => $osId]);
            $response['historico'] = $stmtHistorico->fetchAll(PDO::FETCH_ASSOC);


            // 5. Buscar Itens Aplicados (Micro)
            // ... (código da busca de execução sem mudança) ...
            $sqlExecucao = "
                SELECT 
                    ex.id, 
                    ex.id_item, 
                    ex.tipo_item, 
                    ex.quantidade_aplicada,
                    ex.observacao,
                    ex.timestamp_execucao, 
                    u.username AS usuario_aplicou,
                    CASE 
                        WHEN ex.tipo_item = 'material' THEN m.material
                        WHEN ex.tipo_item = 'estrutura' THEN e.nome
                        ELSE 'Item Desconhecido'
                    END AS nome_item,
                    CASE 
                        WHEN ex.tipo_item = 'material' THEN med.unidade
                        WHEN ex.tipo_item = 'estrutura' THEN 'UN'
                        ELSE 'UN'
                    END AS unidade
                FROM os_execucao_itens ex
                JOIN usuarios u ON ex.id_usuario = u.id
                LEFT JOIN p_material m ON ex.id_item = m.id AND ex.tipo_item = 'material'
                LEFT JOIN medidas med ON m.id_medida = med.id
                LEFT JOIN estruturas e ON ex.id_item = e.id AND ex.tipo_item = 'estrutura'
                WHERE ex.id_componente = :osId
                ORDER BY ex.timestamp_execucao DESC
            ";
            $stmtExecucao = $pdo->prepare($sqlExecucao);
            $stmtExecucao->execute(['osId' => $osId]);
            $response['execucao'] = $stmtExecucao->fetchAll(PDO::FETCH_ASSOC);


            // >>> INÍCIO DA MODIFICAÇÃO (PARA CENÁRIO 3) <<<
            // 6. Verificar o Perfil do Usuário (Líder ou Equipe)
            $projectId = $osGeralData['id_projeto'];
            $stmtLider = $pdo->prepare("SELECT COUNT(*) FROM projeto_lideres WHERE id_projeto = :projectId AND id_usuario_lider = :userId");
            $stmtLider->execute(['projectId' => $projectId, 'userId' => $userId]);
            $isLider = (bool) $stmtLider->fetchColumn();

            $userRole = $isLider ? 'lider' : 'equipe';
            // >>> FIM DA MODIFICAÇÃO <<<


            http_response_code(200);
            // Adiciona o 'user_role' na resposta JSON principal
            echo json_encode(['success' => true, 'data' => $response, 'user_role' => $userRole]);
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em getOSDetails: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao buscar detalhes da OS.']);
        }
    }

    public function uploadOSPhoto($osId)
    {
        header('Access-Control-Allow-Origin: *');
        header('Content-Type: application/json; charset=UTF-8');

        try {
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido.']);
                return;
            }

            if (empty($osId) || !isset($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Nenhuma foto ou ID da OS foi enviado.']);
                return;
            }

            $descricao = $_POST['descricao'] ?? 'Sem descrição';
            $latFoto = $_POST['lat'] ?? null;
            $lonFoto = $_POST['lon'] ?? null;

            $uploadDir = __DIR__ . '/../public/uploads/os_photos/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

            $fileExtension = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
            $fileName = "os_{$osId}_user_{$userId}_" . time() . "." . $fileExtension;
            $filePath = $uploadDir . $fileName;
            $fileUrl = 'uploads/os_photos/' . $fileName;

            if (!move_uploaded_file($_FILES['photo']['tmp_name'], $filePath)) {
                throw new Exception('Falha ao guardar o ficheiro no servidor.');
            }

            $pdo = getDbConnection();
            $distancia = null;
            $alertaDistancia = false; // ===== VARIÁVEL DE ALERTA =====
            $limiteMetros = 50;     // ===== DEFINIMOS O NOSSO LIMITE DE DISTÂNCIA =====

            if ($latFoto && $lonFoto) {
                $stmtOS = $pdo->prepare("SELECT latitude, longitude FROM projeto_componentes WHERE id = :osId");
                $stmtOS->execute(['osId' => $osId]);
                $osCoords = $stmtOS->fetch(PDO::FETCH_ASSOC);

                if ($osCoords) {
                    $distancia = self::_calculateDistance((float)$latFoto, (float)$lonFoto, (float)$osCoords['latitude'], (float)$osCoords['longitude']);

                    // ===== VERIFICAÇÃO DE DISTÂNCIA =====
                    if ($distancia > $limiteMetros) {
                        $alertaDistancia = true;
                    }
                }
            }

            // Adicionamos a coluna 'alerta_distancia' na nossa query
            $sql = "INSERT INTO os_photos 
                    (id_os_componente, id_usuario_upload, caminho_arquivo, descricao, tipo_foto, latitude_foto, longitude_foto, distancia_do_ponto_metros, alerta_distancia) 
                VALUES 
                    (:osId, :userId, :path, :desc, 'validacao', :lat, :lon, :dist, :alerta)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                'osId' => $osId,
                'userId' => $userId,
                'path' => $fileUrl,
                'desc' => $descricao,
                'lat' => $latFoto,
                'lon' => $lonFoto,
                'dist' => $distancia,
                'alerta' => (int)$alertaDistancia // Converte booleano para 1 ou 0
            ]);

            http_response_code(200);
            // ===== RESPOSTA MELHORADA =====
            // Agora, devolvemos o resultado da verificação para a aplicação
            echo json_encode([
                'success' => true,
                'message' => 'Foto enviada com sucesso!',
                'distancia' => $distancia,
                'alerta' => $alertaDistancia
            ]);
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em uploadOSPhoto: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao processar a foto.']);
        }
    }

    // ===== ADICIONE ESTA NOVA FUNÇÃO PRIVADA DENTRO DA CLASSE ApiController =====
    /**
     * Calcula a distância em metros entre dois pontos geográficos (fórmula de Haversine).
     */
    private static function _calculateDistance(float $lat1, float $lon1, float $lat2, float $lon2): int
    {
        $earthRadius = 6371000; // Raio da Terra em metros
        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);
        $a = sin($dLat / 2) * sin($dLat / 2) +
            cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
            sin($dLon / 2) * sin($dLon / 2);
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        return (int)($earthRadius * $c);
    }

    /**
     * Atualiza a posição geográfica de uma OS (componente).
     * Recebe dados via POST JSON: {"latitude": -1.234, "longitude": -48.567}
     */
    public function updateOSPosition($osId)
    {
        header('Access-Control-Allow-Origin: *'); // Permite requisições de qualquer origem (ajuste se necessário)
        header('Access-Control-Allow-Methods: POST, OPTIONS'); // Permite POST e OPTIONS (para preflight)
        header('Access-Control-Allow-Headers: Content-Type, Authorization'); // Cabeçalhos permitidos
        header('Content-Type: application/json; charset=UTF-8');

        // Lida com requisições OPTIONS (preflight CORS)
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            http_response_code(200);
            exit();
        }


        try {
            // 1. Validar Token
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido ou expirado.']);
                return;
            }

            // 2. Validar ID da OS
            if (empty($osId)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'ID da OS não fornecido.']);
                return;
            }

            // 3. Ler e Validar Input JSON
            $data = json_decode(file_get_contents('php://input'), true);
            $newLatitude = $data['latitude'] ?? null;
            $newLongitude = $data['longitude'] ?? null;
            $observacao = trim($data['observacao'] ?? '');

            // Verificação básica se são números válidos
            if (!is_numeric($newLatitude) || !is_numeric($newLongitude)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Coordenadas de latitude e longitude inválidas ou ausentes.']);
                return;
            }

            if (empty($observacao) || strlen($observacao) < 8) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Justificativa é obrigatória e deve ter no mínimo 8 caracteres.']);
                return;
            }

            $pdo = getDbConnection();

            // 4. Atualizar Posição no Banco
            $sql = "UPDATE projeto_componentes
                SET latitude = :latitude, longitude = :longitude, ultima_alteracao_por = :userId, data_ultima_alteracao = NOW()
                WHERE id = :osId";

            $stmt = $pdo->prepare($sql);
            $success = $stmt->execute([
                'latitude' => $newLatitude,
                'longitude' => $newLongitude,
                'userId' => $userId, // Guardamos quem alterou
                'osId' => $osId
            ]);

            if ($success && $stmt->rowCount() > 0) {
                // (Opcional, mas recomendado) Adicionar log de auditoria
                $stmtStatus = $pdo->prepare("SELECT status FROM projeto_componentes WHERE id = :osId");
                $stmtStatus->execute(['osId' => $osId]);
                $currentStatus = $stmtStatus->fetchColumn() ?: 'desconhecido';

                self::logComponenteActivity($osId, $userId, null, 'POSICAO_ATUALIZADA', $observacao, $newLatitude, $newLongitude, $currentStatus, $currentStatus);

                http_response_code(200);
                echo json_encode(['success' => true, 'message' => 'Posição da OS #' . $osId . ' atualizada com sucesso.']);
            } elseif ($success && $stmt->rowCount() == 0) {
                http_response_code(404); // Ou 304 Not Modified
                echo json_encode(['success' => false, 'message' => 'OS não encontrada ou posição já era a mesma.']);
            } else {
                throw new Exception('Falha ao executar a atualização no banco de dados.');
            }
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em updateOSPosition: " . $e->getMessage());
            // Mostra o erro real se estiver em ambiente de desenvolvimento (CUIDADO em produção)
            // echo json_encode(['success' => false, 'message' => 'Erro interno do servidor: ' . $e->getMessage()]);
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao atualizar a posição.']);
        }
    }

    /**
     * Função auxiliar para registrar atividade no log (ADICIONE SE NÃO EXISTIR AINDA)
     */
    private static function logComponenteActivity(int $componenteId, int $usuarioId, ?int $equipeId, string $acao, string $obs, ?float $lat = null, ?float $lon = null, ?string $statusAnt = null, ?string $statusNovo = null)
    {
        try {
            // Log inicial para ver o que foi recebido
            // -> error_log("DEBUG logComponenteActivity: Called with statusAnt='{$statusAnt}', statusNovo='{$statusNovo}' for OS ID {$componenteId}");

            if ($statusNovo === null) {
                // Se statusNovo for null, usa o statusAnt como fallback.
                // Se ambos forem null, usa 'desconhecido'.
                $statusNovo = $statusAnt ?? 'desconhecido';
                error_log("AVISO: logComponenteActivity chamada com status_novo NULL para OS ID {$componenteId}. Usando fallback: {$statusNovo}");
            }

            $pdo = getDbConnection();
            $sql = "INSERT INTO componente_atividades_log
                (id_componente, id_usuario, id_equipe, tipo_acao, observacao, latitude, longitude, status_anterior, status_novo, timestamp_acao)
            VALUES
                (:comp_id, :user_id, :team_id, :acao, :obs, :lat, :lon, :st_ant, :st_novo, NOW())";
            $stmt = $pdo->prepare($sql);

            // <<< NOVO LOG AQUI >>>
            // Cria um array com os parâmetros que serão enviados para o execute
            $paramsToExecute = [
                'comp_id' => $componenteId,
                'user_id' => $usuarioId,
                'team_id' => $equipeId,
                'acao' => $acao,
                'obs' => $obs,
                'lat' => $lat,
                'lon' => $lon,
                'st_ant' => $statusAnt,
                'st_novo' => $statusNovo // O valor que realmente vai para o banco
            ];
            // Loga esses parâmetros no error.log
            // -> error_log("DEBUG logComponenteActivity: Params JUST BEFORE EXECUTE = " . print_r($paramsToExecute, true));
            // <<< FIM DO NOVO LOG >>>

            // Executa a query usando o array de parâmetros
            $stmt->execute($paramsToExecute);
        } catch (PDOException $e) {
            error_log("Erro ao registrar log de atividade do componente: " . $e->getMessage());
            // Não interrompe o fluxo principal se o log falhar
        }
    }

    /**
     * Adiciona um item (material avulso ou estrutura) a uma OS (componente).
     * Recebe dados via POST JSON: {"item_id": 123, "item_type": "material", "quantity": 5}
     * OU {"item_id": 45, "item_type": "estrutura", "quantity": 1}
     */
    /*
    public function addItemToOS($osId)
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        header('Content-Type: application/json; charset=UTF-8');

        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            http_response_code(200);
            exit();
        }

        try {
            // 1. Validar Token
            $userId = AuthManager::getUserIdFromToken(); // <<< Verifique se esta função está correta em AuthManager
            if (!$userId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido ou expirado.']);
                return;
            }

            // 2. Validar ID da OS
            if (empty($osId)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'ID da OS não fornecido.']);
                return;
            }

            // 3. Ler e Validar Input JSON
            $data = json_decode(file_get_contents('php://input'), true);
            $itemId = filter_var($data['item_id'] ?? null, FILTER_VALIDATE_INT);
            $itemType = trim($data['item_type'] ?? ''); // 'material' ou 'estrutura'
            $quantity = filter_var($data['quantity'] ?? null, FILTER_VALIDATE_FLOAT); // Usar FLOAT para quantidade
            $observacao = trim($data['observacao'] ?? '');

            if (!$itemId || empty($itemType) || $quantity === false || $quantity <= 0) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Dados do item inválidos (ID, Tipo ou Quantidade).']);
                return;
            }

            if ($itemType !== 'material' && $itemType !== 'estrutura') {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Tipo de item inválido. Deve ser "material" ou "estrutura".']);
                return;
            }

            if (empty($observacao) || strlen($observacao) < 8) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Justificativa é obrigatória e deve ter no mínimo 8 caracteres.']);
                return;
            }

            $pdo = getDbConnection();
            $tableName = '';
            $idColumnName = '';
            $itemIdColumnName = '';

            // 4. Determinar a tabela e colunas com base no tipo
            if ($itemType === 'material') {
                $tableName = 'componente_materiais_avulsos';
                $idColumnName = 'id_componente';
                $itemIdColumnName = 'id_material';
            } else { // itemType === 'estrutura'
                $tableName = 'componente_estruturas';
                $idColumnName = 'id_componente';
                $itemIdColumnName = 'id_estrutura';
                // Quantidade para estrutura deve ser inteiro
                $quantity = (int)$quantity;
                if ($quantity <= 0) $quantity = 1; // Garante pelo menos 1
            }

            // 5. VERIFICAR SE O ITEM JÁ EXISTE PARA ESTA OS (Evitar duplicados diretos)
            $stmtCheck = $pdo->prepare("SELECT id, quantidade FROM {$tableName} WHERE {$idColumnName} = :osId AND {$itemIdColumnName} = :itemId");
            $stmtCheck->execute(['osId' => $osId, 'itemId' => $itemId]);
            $existingItem = $stmtCheck->fetch(PDO::FETCH_ASSOC);

            $newItemAdded = false;
            $quantityUpdated = false;

            if ($existingItem) {
                // Item já existe - ATUALIZA A QUANTIDADE (Soma a nova quantidade à existente)
                $newQuantity = $existingItem['quantidade'] + $quantity;
                $stmtUpdate = $pdo->prepare("UPDATE {$tableName} SET quantidade = :newQuantity, ultima_alteracao_por = :userId, data_ultima_alteracao = NOW() WHERE id = :existingId");
                $success = $stmtUpdate->execute([
                    'newQuantity' => $newQuantity,
                    'userId' => $userId,
                    'existingId' => $existingItem['id']
                ]);
                if ($success) $quantityUpdated = true;
            } else {
                // Item não existe - INSERE NOVO REGISTRO
                $sqlInsert = "INSERT INTO {$tableName}
                                ({$idColumnName}, {$itemIdColumnName}, quantidade, criado_por, data_cadastro, ultima_alteracao_por, data_ultima_alteracao)
                              VALUES
                                (:osId, :itemId, :quantity, :criadoPor, NOW(), :alteradoPor, NOW())"; // <<< Placeholders únicos :criadoPor, :alteradoPor

                $stmtInsert = $pdo->prepare($sqlInsert);
                // <<< Fornecer valores para os placeholders únicos >>>
                $success = $stmtInsert->execute([
                    'osId' => $osId,
                    'itemId' => $itemId,
                    'quantity' => $quantity,
                    'criadoPor' => $userId, // Mapeia para :criadoPor
                    'alteradoPor' => $userId // Mapeia para :alteradoPor
                ]);
                if ($success) $newItemAdded = true;
            }

            // 6. Registrar Log e Retornar Sucesso/Erro
            if ($newItemAdded || $quantityUpdated) {
                // Busca o nome do item para o log
                $itemNome = self::getItemNameForLog($pdo, $itemType, $itemId); // Função auxiliar
                $logMessage = $observacao;
                $logMessage = ($newItemAdded ? "Adicionado: " : "Quantidade atualizada para: ") . $itemNome . " (Qtd: " . ($newItemAdded ? $quantity : $newQuantity) . ")";

                $stmtStatus = $pdo->prepare("SELECT status FROM projeto_componentes WHERE id = :osId");
                $stmtStatus->execute(['osId' => $osId]);
                $currentStatus = $stmtStatus->fetchColumn() ?: 'desconhecido';

                self::logComponenteActivity($osId, $userId, null, 'ITEM_ADICIONADO_APP', $logMessage, null, null, $currentStatus, $currentStatus);

                http_response_code(200);
                echo json_encode(['success' => true, 'message' => 'Item ' . ($newItemAdded ? 'adicionado' : 'atualizado') . ' com sucesso.']);
            } else {
                throw new Exception('Falha ao salvar o item no banco de dados.');
            }
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em addItemToOS: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao adicionar o item.']);
        }
    }*/


    /**
     * Função auxiliar para buscar o nome do material ou estrutura para o log.
     */
    private static function getItemNameForLog(PDO $pdo, string $itemType, int $itemId): string
    {
        try {
            if ($itemType === 'material') {
                $stmt = $pdo->prepare("SELECT material FROM p_material WHERE id = :id");
            } else { // estrutura
                $stmt = $pdo->prepare("SELECT nome FROM estruturas WHERE id = :id");
            }
            $stmt->execute(['id' => $itemId]);
            $result = $stmt->fetchColumn();
            return $result ?: "Item ID {$itemId}"; // Retorna nome ou ID se não encontrar
        } catch (PDOException $e) {
            error_log("Erro ao buscar nome do item para log: " . $e->getMessage());
            return "Item ID {$itemId}"; // Retorna ID em caso de erro
        }
    }

    /**
     * (NOVA FUNÇÃO) Busca TODOS os materiais e estruturas para o catálogo offline do App.
     * Não usa 'query', envia a lista completa.
     */
    public function getAllItemsApp()
    {
        header('Access-Control-Allow-Origin: *');
        header('Content-Type: application/json; charset=UTF-8');

        try {
            // 1. Validar Token (Garante que só usuários logados podem baixar o catálogo)
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido ou expirado.']);
                return;
            }

            $pdo = getDbConnection();
            $results = [];

            // 2. Buscar em Materiais (p_material)
            $sqlMaterial = "SELECT id, material as nome, codigoMaterial as codigo
                            FROM p_material
                            WHERE ativo = 's'
                            ORDER BY material ASC";
            $stmtMaterial = $pdo->prepare($sqlMaterial);
            $stmtMaterial->execute();
            $materiais = $stmtMaterial->fetchAll(PDO::FETCH_ASSOC);

            foreach ($materiais as $mat) {
                $results[] = [
                    'id' => $mat['id'],
                    'nome' => $mat['nome'],
                    'codigo' => $mat['codigo'],
                    'tipo' => 'material'
                ];
            }

            // 3. Buscar em Estruturas
            $sqlEstrutura = "SELECT id, nome, codigo
                             FROM estruturas
                             ORDER BY nome ASC";
            $stmtEstrutura = $pdo->prepare($sqlEstrutura);
            $stmtEstrutura->execute();
            $estruturas = $stmtEstrutura->fetchAll(PDO::FETCH_ASSOC);

            foreach ($estruturas as $est) {
                $results[] = [
                    'id' => $est['id'],
                    'nome' => $est['nome'],
                    'codigo' => $est['codigo'],
                    'tipo' => 'estrutura'
                ];
            }

            // 4. Retornar Catálogo Completo
            http_response_code(200);
            echo json_encode(['success' => true, 'items' => $results]);
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em getAllItemsApp: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao buscar o catálogo.']);
        }
    }

    /**
     * Busca materiais (p_material) e estruturas por nome ou código para o App.
     * Recebe o termo de busca via parâmetro GET 'query'.
     */
    public function searchItemsApp()
    {
        header('Access-Control-Allow-Origin: *');
        header('Content-Type: application/json; charset=UTF-8');

        try {
            // 1. Validar Token (Garante que só usuários logados no app podem buscar)
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido ou expirado.']);
                return;
            }

            // 2. Obter e Validar o Termo de Busca da URL
            $query = trim($_GET['query'] ?? '');

            // Define um mínimo de caracteres para a busca (ajuste se necessário)
            $minSearchLength = 2;
            if (strlen($query) < $minSearchLength) {
                // Retorna lista vazia se a query for muito curta, em vez de erro
                http_response_code(200);
                echo json_encode(['success' => true, 'items' => []]);
                return;
                // Ou, se preferir retornar erro:
                // http_response_code(400);
                // echo json_encode(['success' => false, 'message' => "Termo de busca deve ter pelo menos {$minSearchLength} caracteres."]);
                // return;
            }

            $pdo = getDbConnection();
            $results = [];
            $searchTerm = '%' . $query . '%'; // Prepara termo para busca com LIKE

            // 3. Buscar em Materiais (p_material) - COM PLACEHOLDERS CORRIGIDOS
            $sqlMaterial = "SELECT id, material as nome, codigoMaterial as codigo
                            FROM p_material
                            WHERE ativo = 's' AND (material LIKE :term1 OR codigoMaterial LIKE :term2) -- <<< Placeholders únicos
                            ORDER BY material ASC
                            LIMIT 10";
            $stmtMaterial = $pdo->prepare($sqlMaterial);
            // <<< Vincular valor a AMBOS os placeholders >>>
            $stmtMaterial->execute(['term1' => $searchTerm, 'term2' => $searchTerm]);
            $materiais = $stmtMaterial->fetchAll(PDO::FETCH_ASSOC);

            foreach ($materiais as $mat) {
                $results[] = [
                    'id' => $mat['id'],
                    'nome' => $mat['nome'],
                    'codigo' => $mat['codigo'],
                    'tipo' => 'material'
                ];
            }

            // 4. Buscar em Estruturas - COM PLACEHOLDERS CORRIGIDOS
            $sqlEstrutura = "SELECT id, nome, codigo
                             FROM estruturas
                             WHERE nome LIKE :term1 OR codigo LIKE :term2 -- <<< Placeholders únicos
                             ORDER BY nome ASC
                             LIMIT 10";
            $stmtEstrutura = $pdo->prepare($sqlEstrutura);
            // <<< Vincular valor a AMBOS os placeholders >>>
            $stmtEstrutura->execute(['term1' => $searchTerm, 'term2' => $searchTerm]);
            $estruturas = $stmtEstrutura->fetchAll(PDO::FETCH_ASSOC);

            foreach ($estruturas as $est) {
                $results[] = [
                    'id' => $est['id'],
                    'nome' => $est['nome'],
                    'codigo' => $est['codigo'],
                    'tipo' => 'estrutura'
                ];
            }

            // 5. Ordenar resultados combinados
            usort($results, function ($a, $b) {
                return strcasecmp($a['nome'], $b['nome']);
            });

            // 6. Retornar Resultados
            http_response_code(200);
            echo json_encode(['success' => true, 'items' => $results]);
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em searchItemsApp: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao buscar itens.']);
        }
    }

    /**
     * Atualiza a quantidade de um item de composição específico (material ou estrutura) em uma OS.
     * Recebe dados via POST JSON: {"item_type": "material", "new_quantity": 3}
     * O ID do item de composição vem da URL.
     */
    public function updateOSItemQuantity($osId, $compItemId)
    {
        // Headers CORS e Content-Type (Copie de outra função se necessário)
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        header('Content-Type: application/json; charset=UTF-8');
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            http_response_code(200);
            exit();
        }

        try {
            // 1. Validar Token
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) { /* ... (retorno 401) ... */
                return;
            }

            // 2. Validar IDs da URL
            if (empty($osId) || empty($compItemId)) { /* ... (retorno 400) ... */
                return;
            }

            // 3. Ler e Validar Input JSON
            $data = json_decode(file_get_contents('php://input'), true);
            $itemType = trim($data['item_type'] ?? '');
            $newQuantity = filter_var($data['new_quantity'] ?? null, FILTER_VALIDATE_FLOAT);

            if (empty($itemType) || $newQuantity === false || $newQuantity <= 0) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Tipo ou nova quantidade inválida.']);
                return;
            }
            if ($itemType !== 'material' && $itemType !== 'estrutura') { /* ... (retorno 400 tipo inválido) ... */
                return;
            }


            $pdo = getDbConnection();
            $tableName = '';

            // 4. Determinar a tabela com base no tipo
            if ($itemType === 'material') {
                $tableName = 'componente_materiais_avulsos';
            } else { // estrutura
                $tableName = 'componente_estruturas';
                $newQuantity = (int)$newQuantity; // Garante inteiro para estrutura
                if ($newQuantity <= 0) $newQuantity = 1;
            }

            // 5. Atualizar a Quantidade no Banco
            // Note que estamos usando o $compItemId (ID da linha na tabela de composição)
            $sqlUpdate = "UPDATE {$tableName}
                      SET quantidade = :newQuantity, ultima_alteracao_por = :userId, data_ultima_alteracao = NOW()
                      WHERE id = :compItemId AND id_componente = :osId"; // Adiciona verificação do osId por segurança

            $stmtUpdate = $pdo->prepare($sqlUpdate);
            $success = $stmtUpdate->execute([
                'newQuantity' => $newQuantity,
                'userId' => $userId,
                'compItemId' => $compItemId,
                'osId' => $osId
            ]);

            // 6. Registrar Log e Retornar
            if ($success && $stmtUpdate->rowCount() > 0) {
                // Busca o nome do item para o log (precisamos buscar o ID original do item primeiro)
                $itemInfo = self::getItemInfoFromCompId($pdo, $itemType, $compItemId); // Nova função auxiliar
                $logMessage = "Qtd. atualizada: " . ($itemInfo['nome'] ?? "Item Comp#{$compItemId}") . " para {$newQuantity}";
                $stmtStatus = $pdo->prepare("SELECT status FROM projeto_componentes WHERE id = :osId");
                $stmtStatus->execute(['osId' => $osId]);
                $currentStatus = $stmtStatus->fetchColumn() ?: 'desconhecido';

                self::logComponenteActivity($osId, $userId, null, 'ITEM_QTD_ATUALIZADA_APP', $logMessage, null, null, $currentStatus, $currentStatus);

                http_response_code(200);
                echo json_encode(['success' => true, 'message' => 'Quantidade atualizada com sucesso.']);
            } elseif ($success && $stmtUpdate->rowCount() == 0) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Item não encontrado nesta OS ou quantidade já era a mesma.']);
            } else {
                throw new Exception('Falha ao atualizar a quantidade no banco de dados.');
            }
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em updateOSItemQuantity: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao atualizar quantidade.']);
        }
    }


    /**
     * Remove um item de composição específico (material ou estrutura) de uma OS.
     * Recebe dados via POST JSON: {"item_type": "material"}
     * O ID do item de composição vem da URL.
     */
    public function removeOSItem($osId, $compItemId)
    {
        // Headers CORS e Content-Type (Copie de outra função)
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, OPTIONS'); // Permitimos POST aqui
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        header('Content-Type: application/json; charset=UTF-8');
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            http_response_code(200);
            exit();
        }

        try {
            // 1. Validar Token
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) { /* ... (retorno 401) ... */
                return;
            }

            // 2. Validar IDs da URL
            if (empty($osId) || empty($compItemId)) { /* ... (retorno 400) ... */
                return;
            }

            // 3. Ler e Validar Input JSON (apenas para saber o tipo e logar)
            $data = json_decode(file_get_contents('php://input'), true);
            $itemType = trim($data['item_type'] ?? '');
            if (empty($itemType) || ($itemType !== 'material' && $itemType !== 'estrutura')) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Tipo de item inválido ou ausente.']);
                return;
            }

            $pdo = getDbConnection();
            $tableName = '';

            // 4. Determinar a tabela com base no tipo
            $tableName = ($itemType === 'material') ? 'componente_materiais_avulsos' : 'componente_estruturas';

            // Busca o nome ANTES de deletar para usar no log
            $itemInfo = self::getItemInfoFromCompId($pdo, $itemType, $compItemId);

            // 5. Deletar o Item no Banco
            // Usamos o $compItemId (ID da linha na tabela de composição)
            $sqlDelete = "DELETE FROM {$tableName} WHERE id = :compItemId AND id_componente = :osId";

            $stmtDelete = $pdo->prepare($sqlDelete);
            $success = $stmtDelete->execute([
                'compItemId' => $compItemId,
                'osId' => $osId
            ]);

            // 6. Registrar Log e Retornar
            if ($success && $stmtDelete->rowCount() > 0) {
                $logMessage = "Removido: " . ($itemInfo['nome'] ?? "Item Comp#{$compItemId}");
                $stmtStatus = $pdo->prepare("SELECT status FROM projeto_componentes WHERE id = :osId");
                $stmtStatus->execute(['osId' => $osId]);
                $currentStatus = $stmtStatus->fetchColumn() ?: 'desconhecido';

                self::logComponenteActivity($osId, $userId, null, 'ITEM_REMOVIDO_APP', $logMessage, null, null, $currentStatus, $currentStatus);

                http_response_code(200);
                echo json_encode(['success' => true, 'message' => 'Item removido com sucesso.']);
            } elseif ($success && $stmtDelete->rowCount() == 0) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Item não encontrado nesta OS.']);
            } else {
                throw new Exception('Falha ao remover o item do banco de dados.');
            }
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em removeOSItem: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao remover item.']);
        }
    }

    /**
     * Função auxiliar para buscar o ID e nome do material/estrutura original
     * a partir do ID da linha na tabela de composição (componente_...).
     * Retorna ['id' => original_id, 'nome' => nome_item] ou null.
     */
    private static function getItemInfoFromCompId(PDO $pdo, string $itemType, int $compItemId): ?array
    {
        try {
            if ($itemType === 'material') {
                $sql = "SELECT cma.id_material as id, m.material as nome
                     FROM componente_materiais_avulsos cma
                     JOIN p_material m ON cma.id_material = m.id
                     WHERE cma.id = :compId";
            } else { // estrutura
                $sql = "SELECT ce.id_estrutura as id, e.nome
                     FROM componente_estruturas ce
                     JOIN estruturas e ON ce.id_estrutura = e.id
                     WHERE ce.id = :compId";
            }
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['compId' => $compItemId]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result ?: null;
        } catch (PDOException $e) {
            error_log("Erro ao buscar info do item por compId: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Cancela uma OS (componente), definindo o status para 'cancelado'.
     * Exige uma justificativa (observacao) no corpo do JSON.
     */
    // controllers/ApiController.php

    // ... (Outras funções)

    public function cancelOS($osId)
    {
        header('Access-Control-Allow-Origin: *');
        header('Content-Type: application/json; charset=UTF-8');
        // Adicionamos a lógica de OPTIONS que existe nas outras funções
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            http_response_code(200);
            exit();
        }

        try {
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido ou expirado.']);
                return;
            }
            if (empty($osId)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'ID da OS não fornecido.']);
                return;
            }

            // 1. Ler Justificativa e Validar (Obrigatória)
            $data = json_decode(file_get_contents('php://input'), true);
            $observacao = trim($data['observacao'] ?? '');

            if (empty($observacao) || strlen($observacao) < 8) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Justificativa é obrigatória e deve ter no mínimo 8 caracteres.']);
                return;
            }

            $pdo = getDbConnection();

            // 2. BUSCAR STATUS ATUAL E APLICAR REGRA DE NEGÓCIO
            $stmtStatus = $pdo->prepare("SELECT status FROM projeto_componentes WHERE id = :osId");
            $stmtStatus->execute(['osId' => $osId]);
            $currentStatus = $stmtStatus->fetchColumn();

            $allowedStatuses = ['planejado', 'em_andamento'];
            if (!$currentStatus || !in_array($currentStatus, $allowedStatuses)) {
                http_response_code(409); // Conflito
                $message = $currentStatus ? "O cancelamento é permitido apenas quando a OS está Planeada ou Liberada. Status atual: {$currentStatus}." : 'OS não encontrada.';
                echo json_encode(['success' => false, 'message' => $message]);
                return;
            }

            // 3. ATUALIZAR O STATUS PARA 'cancelado'
            $sql = "UPDATE projeto_componentes
                    SET status = 'cancelado', ultima_alteracao_por = :userId, data_ultima_alteracao = NOW()
                    WHERE id = :osId AND status IN ('planejado', 'em_andamento')"; // Dupla checagem no WHERE
            $stmt = $pdo->prepare($sql);
            $success = $stmt->execute(['userId' => $userId, 'osId' => $osId]);

            // ... (Log e resposta de sucesso aqui)
            if ($success && $stmt->rowCount() > 0) {
                self::logComponenteActivity($osId, $userId, null, 'OS_CANCELADA_APP', $observacao, null, null, $currentStatus, 'cancelado');
                http_response_code(200);
                echo json_encode(['success' => true, 'message' => 'OS #' . $osId . ' cancelada com sucesso.']);
            } else {
                http_response_code(409);
                echo json_encode(['success' => false, 'message' => 'OS não pôde ser cancelada.']);
            }
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em cancelOS: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao cancelar a OS.']);
        }
    }

    /**
     * Lida com o processo de check-in da equipe via App.
     * Recebe foto, lista de matrículas e coordenadas via POST multipart/form-data.
     */
    public function performCheckin()
    {
        // Headers CORS e Content-Type (ajuste se necessário)
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        header('Content-Type: application/json; charset=UTF-8');
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            http_response_code(200);
            exit();
        }

        try {
            // 1. Validar Token do usuário que está fazendo o check-in
            $uploaderUserId = AuthManager::getUserIdFromToken();
            if (!$uploaderUserId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido ou expirado.']);
                return;
            }

            // 2. Validar Inputs (Foto, Matrículas, Lat/Lon)
            if (!isset($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Foto da equipe não enviada ou inválida.']);
                return;
            }

            $matriculasJson = $_POST['matriculas'] ?? '[]'; // Espera um JSON array como string: "[\"123\",\"456\"]"
            $attendeeMatriculas = json_decode($matriculasJson, true); // Decodifica para array PHP

            if (json_last_error() !== JSON_ERROR_NONE || !is_array($attendeeMatriculas) || empty($attendeeMatriculas)) {
                http_response_code(400);
                error_log("Erro Matriculas JSON: " . json_last_error_msg() . " | Input Recebido: " . $matriculasJson); // Log para debug
                echo json_encode(['success' => false, 'message' => 'Lista de matrículas inválida ou vazia. Envie como JSON array string.']);
                return;
            }


            $latitude = filter_var($_POST['lat'] ?? null, FILTER_VALIDATE_FLOAT, FILTER_NULL_ON_FAILURE);
            $longitude = filter_var($_POST['lon'] ?? null, FILTER_VALIDATE_FLOAT, FILTER_NULL_ON_FAILURE);

            // (Opcional) Validação extra das coordenadas, se necessário

            // 3. Salvar a Foto
            $uploadDir = __DIR__ . '/../public/uploads/checkin_photos/'; // Caminho relativo ao ApiController
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

            $fileExtension = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
            // Nome do arquivo: checkin_userid_timestamp.ext
            $fileName = "checkin_{$uploaderUserId}_" . time() . "." . $fileExtension;
            $filePath = $uploadDir . $fileName;
            // Caminho relativo à pasta public para guardar no DB
            $fileUrl = 'uploads/checkin_photos/' . $fileName;

            if (!move_uploaded_file($_FILES['photo']['tmp_name'], $filePath)) {
                throw new Exception('Falha ao guardar a foto de check-in no servidor.');
            }

            // 4. Inserir no Banco de Dados
            $pdo = getDbConnection();
            $sql = "INSERT INTO attendance_checkins
                    (attendee_matriculas, photo_url, latitude, longitude, uploader_user_id, checkin_timestamp)
                VALUES
                    (:matriculas, :photo_url, :lat, :lon, :uploader_id, NOW())";

            $stmt = $pdo->prepare($sql);
            $success = $stmt->execute([
                'matriculas' => json_encode($attendeeMatriculas), // Salva como JSON string
                'photo_url' => $fileUrl,
                'lat' => $latitude,
                'lon' => $longitude,
                'uploader_id' => $uploaderUserId
            ]);

            if ($success) {
                http_response_code(201); // 201 Created
                echo json_encode(['success' => true, 'message' => 'Check-in registrado com sucesso!']);
            } else {
                // Se falhou, tenta remover a foto que foi salva
                if (file_exists($filePath)) unlink($filePath);
                throw new Exception('Falha ao registrar o check-in no banco de dados.');
            }
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em performCheckin: " . $e->getMessage());
            // Tenta remover a foto se ela existe e houve erro no DB
            if (isset($filePath) && file_exists($filePath)) {
                unlink($filePath);
            }
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor durante o check-in: ' . $e->getMessage()]);
        }
    }

    /**
     * Inicia a execução de uma OS, recebendo a foto "ANTES" obrigatória.
     * Muda o status da OS para 'em_execucao'.
     */
    public function startExecution($osId)
    {
        // Headers CORS e Content-Type (Copie de outra função)
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        header('Content-Type: application/json; charset=UTF-8');
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            http_response_code(200);
            exit();
        }

        try {
            // 1. Validar Token
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido ou expirado.']);
                return;
            }

            // 2. Validar ID da OS e Foto
            if (empty($osId)) { /* ... (retorno 400 ID ausente) ... */
                return;
            }
            if (!isset($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Foto "ANTES" obrigatória não enviada.']);
                return;
            }

            // 3. Obter dados adicionais (lat/lon podem vir do POST)
            $descricao = $_POST['descricao'] ?? 'Foto ANTES'; // Descrição padrão
            $latFoto = filter_var($_POST['lat'] ?? null, FILTER_VALIDATE_FLOAT, FILTER_NULL_ON_FAILURE);
            $lonFoto = filter_var($_POST['lon'] ?? null, FILTER_VALIDATE_FLOAT, FILTER_NULL_ON_FAILURE);

            $pdo = getDbConnection();

            // 4. Verificar se a OS está no status correto ('em_andamento')
            $stmtCheck = $pdo->prepare("SELECT status FROM projeto_componentes WHERE id = :osId");
            $stmtCheck->execute(['osId' => $osId]);
            $currentStatus = $stmtCheck->fetchColumn();

            if ($currentStatus !== 'em_andamento') {
                http_response_code(409); // Conflito
                echo json_encode(['success' => false, 'message' => 'Esta OS não está liberada para execução (status atual: ' . $currentStatus . ').']);
                return;
            }


            // 5. Salvar a Foto (similar a uploadOSPhoto, mas com type='antes')
            $uploadDir = __DIR__ . '/../public/uploads/os_photos/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
            $fileExtension = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
            $fileName = "os_{$osId}_user_{$userId}_antes_" . time() . "." . $fileExtension;
            $filePath = $uploadDir . $fileName;
            $fileUrl = 'uploads/os_photos/' . $fileName;

            if (!move_uploaded_file($_FILES['photo']['tmp_name'], $filePath)) {
                throw new Exception('Falha ao guardar a foto "ANTES" no servidor.');
            }

            // Calcular distância (opcional aqui, mas pode ser útil)
            $distancia = null;
            $alertaDistancia = false;
            if ($latFoto && $lonFoto) {
                // Reutiliza a função _calculateDistance
                $stmtOSCoords = $pdo->prepare("SELECT latitude, longitude FROM projeto_componentes WHERE id = :osId");
                $stmtOSCoords->execute(['osId' => $osId]);
                $osCoords = $stmtOSCoords->fetch(PDO::FETCH_ASSOC);
                if ($osCoords) {
                    // Define o limite (pode vir de config/constants.php depois)
                    $limiteMetros = $_ENV['PHOTO_DISTANCE_LIMIT_METERS'] ?? 50; // Usa 50 como padrão
                    $distancia = self::_calculateDistance((float)$latFoto, (float)$lonFoto, (float)$osCoords['latitude'], (float)$osCoords['longitude']);
                    if ($distancia > $limiteMetros) {
                        $alertaDistancia = true;
                    }
                }
            }


            // 6. Inserir registro da foto na tabela os_photos com type='antes'
            $sqlPhoto = "INSERT INTO os_photos
                        (id_os_componente, id_usuario_upload, caminho_arquivo, descricao, type, latitude_foto, longitude_foto, distancia_do_ponto_metros, alerta_distancia)
                     VALUES
                        (:osId, :userId, :path, :desc, 'antes', :lat, :lon, :dist, :alerta)";
            $stmtPhoto = $pdo->prepare($sqlPhoto);
            $photoSuccess = $stmtPhoto->execute([
                'osId' => $osId,
                'userId' => $userId,
                'path' => $fileUrl,
                'desc' => $descricao,
                'lat' => $latFoto,
                'lon' => $lonFoto,
                'dist' => $distancia,
                'alerta' => (int)$alertaDistancia
            ]);

            if (!$photoSuccess) {
                if (file_exists($filePath)) unlink($filePath); // Tenta remover foto se falhou DB
                throw new Exception('Falha ao registrar a foto "ANTES" no banco.');
            }

            // 7. Atualizar Status da OS para 'em_execucao'
            $sqlOS = "UPDATE projeto_componentes
                  SET status = 'em_execucao', ultima_alteracao_por = :userId, data_ultima_alteracao = NOW()
                  WHERE id = :osId AND status = 'em_andamento'"; // Dupla checagem de status
            $stmtOS = $pdo->prepare($sqlOS);
            $osSuccess = $stmtOS->execute(['userId' => $userId, 'osId' => $osId]);

            $rowCount = $stmtOS->rowCount(); // Pega o número de linhas afetadas

            // -> error_log("DEBUG startExecution: UPDATE osSuccess = " . ($osSuccess ? 'true' : 'false'));
            // -> error_log("DEBUG startExecution: UPDATE rowCount = " . $rowCount); // LOG ESSENCIAL!

            // <<< ADICIONE ESTE BLOCO PARA RE-CONSULTAR O STATUS >>>
            if ($osSuccess && $rowCount > 0) {
                try {
                    // Re-consulta o status da OS que acabamos de tentar atualizar
                    $stmtVerify = $pdo->prepare("SELECT status FROM projeto_componentes WHERE id = :osId");
                    $stmtVerify->execute(['osId' => $osId]);
                    $statusAfterUpdate = $stmtVerify->fetchColumn(); // Pega apenas o valor da coluna status

                    // Loga o status encontrado IMEDIATAMENTE após o UPDATE
                    // -> error_log("DEBUG startExecution: Status IN DB IMMEDIATELY AFTER UPDATE = " . ($statusAfterUpdate !== false ? var_export($statusAfterUpdate, true) : 'NOT FOUND'));
                } catch (PDOException $verifyError) {
                    // Loga se a consulta de verificação falhar
                    error_log("ERRO startExecution: Falha ao verificar status após UPDATE: " . $verifyError->getMessage());
                }
            }
            // <<< FIM DO BLOCO ADICIONADO >>>

            if (!$osSuccess || $stmtOS->rowCount() == 0) {
                if (file_exists($filePath)) unlink($filePath); // Tenta remover foto
                // (Opcional) Tentar deletar o registro da foto que foi inserido
                $pdo->prepare("DELETE FROM os_photos WHERE caminho_arquivo = :path")->execute(['path' => $fileUrl]);

                error_log("ERRO startExecution: Falha ao atualizar status ou rowCount foi zero. OS ID: {$osId}");

                throw new Exception('Falha ao atualizar o status da OS para Em Execução.');
            }

            if ($stmtOS->rowCount() == 0) {
                // A query executou, mas nenhuma linha foi alterada.
                // Isso pode acontecer se o status JÁ era 'em_execucao' ou outro.
                if (file_exists($filePath)) unlink($filePath);
                $pdo->prepare("DELETE FROM os_photos WHERE caminho_arquivo = :path")->execute(['path' => $fileUrl]);

                // Busca o status atual para dar uma mensagem mais informativa
                $stmtCheckAgain = $pdo->prepare("SELECT status FROM projeto_componentes WHERE id = :osId");
                $stmtCheckAgain->execute(['osId' => $osId]);
                $actualStatus = $stmtCheckAgain->fetchColumn();

                http_response_code(409); // Conflito
                echo json_encode(['success' => false, 'message' => 'Não foi possível iniciar a execução. Status atual da OS: ' . ($actualStatus ?: 'NÃO ENCONTRADO')]);
                return; // Interrompe a execução aqui
            }

            // 8. Registrar Log da Atividade
            self::logComponenteActivity(
                $osId,
                $userId,
                null, // equipeId pode ser adicionado se disponível no token/requisição
                'INICIO_EXECUCAO_APP',
                'Início da execução registrado com foto ANTES.',
                $latFoto,
                $lonFoto,
                'em_andamento', // Status anterior
                'em_execucao'   // Novo status
            );

            // 9. Retornar Sucesso
            http_response_code(200);
            echo json_encode([
                'success' => true,
                'message' => 'Execução da OS #' . $osId . ' iniciada com sucesso.',
                'new_status' => 'em_execucao',
                'photo_info' => [ // Retorna info da foto salva
                    'url' => $fileUrl,
                    'distancia' => $distancia,
                    'alerta' => $alertaDistancia
                ]
            ]);
        } catch (\Throwable $e) {
            // ... (Bloco catch similar aos outros, tenta remover a foto se foi salva) ...
            http_response_code(500);
            error_log("ERRO FATAL em startExecution: " . $e->getMessage());
            if (isset($filePath) && file_exists($filePath)) {
                unlink($filePath);
            }
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao iniciar execução: ' . $e->getMessage()]);
        }
    }

    /**
     * (NOVO - FLUXO EQUIPE) Registra um material/estrutura aplicado pela equipe (Micro).
     * Recebe dados via POST JSON: {"item_id": 123, "item_type": "material", "quantity": 5, "observacao": "..."}
     */
    /*
    public function applyItemToOS($osId)
    {
        // Headers CORS (sem mudanças)
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        header('Content-Type: application/json; charset=UTF-8');
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            http_response_code(200);
            exit();
        }

        try {
            // 1. Validar Token (sem mudanças)
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido ou expirado.']);
                return;
            }

            // 2. Validar ID da OS (sem mudanças)
            if (empty($osId)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'ID da OS não fornecido.']);
                return;
            }

            // 3. Ler e Validar Input JSON
            $data = json_decode(file_get_contents('php://input'), true);
            $itemId = filter_var($data['item_id'] ?? null, FILTER_VALIDATE_INT);
            $itemType = trim($data['item_type'] ?? '');
            $quantity = filter_var($data['quantity'] ?? null, FILTER_VALIDATE_FLOAT);

            // <<< MUDANÇA: OBSERVACAO AGORA É OPCIONAL >>>
            $observacao = trim($data['observacao'] ?? ''); // Pega a observação (pode ser vazia)
            if (empty($observacao)) {
                $observacao = null; // Garante que seja NULL no banco se vazia
            }
            // <<< FIM DA MUDANÇA >>>


            if (!$itemId || empty($itemType) || $quantity === false || $quantity <= 0) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Dados do item inválidos (ID, Tipo ou Quantidade).']);
                return;
            }
            if ($itemType !== 'material' && $itemType !== 'estrutura') {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Tipo de item inválido.']);
                return;
            }

            // <<< MUDANÇA: REMOVIDA A VERIFICAÇÃO DE JUSTIFICATIVA OBRIGATÓRIA >>>

            if ($itemType === 'estrutura') {
                $quantity = (int)$quantity;
            }

            $pdo = getDbConnection();

            // 4. Inserir na nova tabela (agora com a coluna 'observacao')
            $sql = "INSERT INTO os_execucao_itens
                        (id_componente, id_item, tipo_item, quantidade_aplicada, observacao, id_usuario, timestamp_execucao)
                    VALUES
                        (:osId, :itemId, :itemType, :quantity, :observacao, :userId, NOW())";

            $stmt = $pdo->prepare($sql);
            $success = $stmt->execute([
                'osId' => $osId,
                'itemId' => $itemId,
                'itemType' => $itemType,
                'quantity' => $quantity,
                'observacao' => $observacao, // Salva a observação (ou null)
                'userId' => $userId
            ]);

            if ($success) {
                // 5. Registrar no Log de Atividades
                $itemNome = self::getItemNameForLog($pdo, $itemType, $itemId);

                // <<< MUDANÇA: Log agora inclui a observação se ela existir >>>
                $logMessage = "Aplicado: {$quantity}x {$itemNome}.";
                if ($observacao) {
                    $logMessage .= " Obs: {$observacao}";
                }
                // <<< FIM DA MUDANÇA >>>

                $stmtStatus = $pdo->prepare("SELECT status FROM projeto_componentes WHERE id = :osId");
                $stmtStatus->execute(['osId' => $osId]);
                $currentStatus = $stmtStatus->fetchColumn() ?: 'em_execucao';

                self::logComponenteActivity($osId, $userId, null, 'ITEM_APLICADO_APP', $logMessage, null, null, $currentStatus, $currentStatus);

                http_response_code(201); // 201 Created
                echo json_encode(['success' => true, 'message' => 'Material aplicado registrado com sucesso!']);
            } else {
                throw new Exception('Falha ao registrar o material aplicado no banco de dados.');
            }
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em applyItemToOS: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao aplicar o item.']);
        }
    }
    */

    /**
     * Marca uma OS como finalizada (mas não concluída), exigindo justificativa.
     * NÃO altera o status principal da OS, apenas registra no log.
     */
    public function finishIncomplete($osId)
    {
        // Headers CORS e Content-Type (Copie de outra função se necessário)
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        header('Content-Type: application/json; charset=UTF-8');
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            http_response_code(200);
            exit();
        }

        try {
            // 1. Validar Token
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido ou expirado.']);
                return;
            }

            // 2. Validar ID da OS
            if (empty($osId)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'ID da OS não fornecido.']);
                return;
            }

            // 3. Ler e Validar Justificativa (observacao)
            $data = json_decode(file_get_contents('php://input'), true);
            $observacao = trim($data['observacao'] ?? '');

            // Validação da justificativa (mínimo 8 caracteres, pode usar a mesma lógica do PHP se tiver)
            if (empty($observacao) || strlen($observacao) < 8) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Justificativa é obrigatória e deve ter no mínimo 8 caracteres.']);
                return;
            }

            $pdo = getDbConnection();

            // 4. Buscar o status ATUAL (para o log e verificar se a OS existe)
            $stmtStatus = $pdo->prepare("SELECT status FROM projeto_componentes WHERE id = :osId");
            $stmtStatus->execute(['osId' => $osId]);
            $currentStatus = $stmtStatus->fetchColumn();

            if (!$currentStatus) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'OS não encontrada.']);
                return;
            }

            // 5. APENAS Registrar o Log (NÃO ALTERA O STATUS DA OS)
            self::logComponenteActivity(
                $osId,
                $userId,
                null, // equipeId (se disponível)
                'FINALIZADO_INCOMPLETO_APP', // Novo tipo de ação
                $observacao, // A justificativa obrigatória
                null, // Lat (opcional)
                null, // Lon (opcional)
                $currentStatus, // Status anterior (ex: 'em_execucao')
                $currentStatus  // Status novo é o MESMO
            );

            // 6. Retornar Sucesso
            http_response_code(200);
            echo json_encode(['success' => true, 'message' => 'OS #' . $osId . ' marcada como finalizada (incompleta).']);
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em finishIncomplete: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao finalizar OS (incompleta).']);
        }
    }

    // >>> INÍCIO DA NOVA FUNÇÃO (completeOS) <<<
    /**
     * Conclui uma OS (100%), definindo o status para 'concluido'.
     * Recebe uma observação opcional.
     */
    public function completeOS($osId)
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        header('Content-Type: application/json; charset=UTF-8');
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            http_response_code(200);
            exit();
        }

        try {
            // 1. Validar Token e IDs
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido.']);
                return;
            }
            if (empty($osId)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'ID da OS não fornecido.']);
                return;
            }

            // 2. Obter observação (opcional)
            $data = json_decode(file_get_contents('php://input'), true);
            $observacao = trim($data['observacao'] ?? '');

            $pdo = getDbConnection();

            // 3. Pega status anterior para o log
            $stmtStatus = $pdo->prepare("SELECT status FROM projeto_componentes WHERE id = :osId");
            $stmtStatus->execute(['osId' => $osId]);
            $currentStatus = $stmtStatus->fetchColumn();

            if ($currentStatus !== 'em_execucao') {
                http_response_code(409); // Conflito
                echo json_encode(['success' => false, 'message' => 'Serviço não está em execução. Status: ' . $currentStatus]);
                return;
            }

            // 4. ATUALIZAR O STATUS DA OS para 'concluido'
            $sql = "UPDATE projeto_componentes
                    SET status = 'concluido', ultima_alteracao_por = :userId, data_ultima_alteracao = NOW()
                    WHERE id = :osId AND status = 'em_execucao'";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['userId' => $userId, 'osId' => $osId]);

            if ($stmt->rowCount() > 0) {
                // 5. Logar a ação
                $logMessage = "Serviço concluído (100%).";
                if (!empty($observacao)) {
                    $logMessage .= " Obs: " . $observacao;
                }

                self::logComponenteActivity(
                    $osId,
                    $userId,
                    null,
                    'SERVICO_CONCLUIDO_APP',
                    $logMessage,
                    null,
                    null,
                    'em_execucao',  // Status anterior
                    'concluido'     // Novo status
                );

                http_response_code(200);
                echo json_encode(['success' => true, 'message' => 'Serviço concluído e enviado para validação!']);
            } else {
                throw new Exception('Falha ao atualizar o status da OS (rowCount = 0).');
            }
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em completeOS: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao concluir OS.']);
        }
    }

    /**
     * (LÍDER) Aprova uma OS, definindo o status para 'validado'.
     * Recebe uma observação opcional.
     */
    public function approveOS($osId)
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        header('Content-Type: application/json; charset=UTF-8');
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            http_response_code(200);
            exit();
        }

        try {
            // 1. Validar Token e IDs
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido.']);
                return;
            }
            if (empty($osId)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'ID da OS não fornecido.']);
                return;
            }

            // 2. Obter observação (opcional)
            $data = json_decode(file_get_contents('php://input'), true);
            $observacao = trim($data['observacao'] ?? '');

            $pdo = getDbConnection();

            // 3. Pega status anterior para o log (só pode aprovar se estiver 'concluido')
            $stmtStatus = $pdo->prepare("SELECT status FROM projeto_componentes WHERE id = :osId");
            $stmtStatus->execute(['osId' => $osId]);
            $currentStatus = $stmtStatus->fetchColumn();

            if ($currentStatus !== 'concluido') {
                http_response_code(409); // Conflito
                echo json_encode(['success' => false, 'message' => 'Este serviço não está aguardando validação. Status: ' . $currentStatus]);
                return;
            }

            // 4. ATUALIZAR O STATUS DA OS para 'validado'
            // NOTA: O status 'validado' (Azul) NÃO ESTÁ no ENUM do banco.
            // Precisamos adicioná-lo primeiro! (Veremos isso a seguir)
            // Por agora, vamos assumir que 'concluido' é o estado final e apenas logamos.
            // Se 'validado' for um status real, precisaremos de um ALTER TABLE.

            // *** VAMOS ASSUMIR QUE O STATUS 'CONCLUIDO' É O FINAL (VERDE) ***
            // *** E QUE APROVAR APENAS ADICIONA UM LOG DE AUDITORIA ***
            // Se 'validado' for um novo status (AZUL), me avise para ajustarmos o SQL.

            // 5. Logar a ação
            $sql = "UPDATE projeto_componentes
                    SET status = 'validado', ultima_alteracao_por = :userId, data_ultima_alteracao = NOW()
                    WHERE id = :osId AND status = 'concluido'";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['userId' => $userId, 'osId' => $osId]);

            if ($stmt->rowCount() > 0) {
                // 5. Logar a ação
                $logMessage = "Serviço APROVADO (Validado) pelo líder.";
                if (!empty($observacao)) {
                    $logMessage .= " Obs: " . $observacao;
                }

                self::logComponenteActivity(
                    $osId,
                    $userId,
                    null,
                    'SERVICO_APROVADO_APP',
                    $logMessage,
                    null,
                    null,
                    'concluido',  // Status anterior (Verde)
                    'validado'    // Status novo (Azul)
                );

                http_response_code(200);
                echo json_encode(['success' => true, 'message' => 'Serviço aprovado e validado!']);
            } else {
                throw new Exception('Falha ao atualizar o status da OS (rowCount = 0).');
            }
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em approveOS: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao aprovar OS.']);
        }
    }
    // >>> FIM DA NOVA FUNÇÃO <<<


    // >>> INÍCIO DA NOVA FUNÇÃO (rejectOS) <<<
    /**
     * (LÍDER) Rejeita uma OS, devolvendo o status para 'em_execucao'.
     * Exige uma justificativa obrigatória.
     */
    public function rejectOS($osId)
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        header('Content-Type: application/json; charset=UTF-8');
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            http_response_code(200);
            exit();
        }

        try {
            // 1. Validar Token e IDs
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido.']);
                return;
            }
            if (empty($osId)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'ID da OS não fornecido.']);
                return;
            }

            // 2. Obter observação (OBRIGATÓRIA)
            $data = json_decode(file_get_contents('php://input'), true);
            $observacao = trim($data['observacao'] ?? '');

            if (empty($observacao) || strlen($observacao) < 8) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Justificativa de rejeição é obrigatória (mín. 8 caracteres).']);
                return;
            }

            $pdo = getDbConnection();

            // 3. Pega status anterior (só pode rejeitar se estiver 'concluido')
            $stmtStatus = $pdo->prepare("SELECT status FROM projeto_componentes WHERE id = :osId");
            $stmtStatus->execute(['osId' => $osId]);
            $currentStatus = $stmtStatus->fetchColumn();

            if ($currentStatus !== 'concluido') {
                http_response_code(409); // Conflito
                echo json_encode(['success' => false, 'message' => 'Este serviço não está aguardando validação. Status: ' . $currentStatus]);
                return;
            }

            // 4. ATUALIZAR O STATUS DA OS de volta para 'em_execucao' (Amarelo)
            $sql = "UPDATE projeto_componentes
                    SET status = 'em_execucao', ultima_alteracao_por = :userId, data_ultima_alteracao = NOW()
                    WHERE id = :osId AND status = 'concluido'";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['userId' => $userId, 'osId' => $osId]);

            if ($stmt->rowCount() > 0) {
                // 5. Logar a ação
                $logMessage = "Serviço REJEITADO pelo líder. Motivo: " . $observacao;

                self::logComponenteActivity(
                    $osId,
                    $userId,
                    null,
                    'SERVICO_REJEITADO_APP',
                    $logMessage,
                    null,
                    null,
                    'concluido',    // Status anterior
                    'em_execucao'   // Novo status (devolvido para equipe)
                );

                http_response_code(200);
                echo json_encode(['success' => true, 'message' => 'Serviço rejeitado e devolvido para execução.']);
            } else {
                throw new Exception('Falha ao atualizar o status da OS (rowCount = 0).');
            }
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em rejectOS: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao rejeitar OS.']);
        }
    }

    /**
     * Inicia a jornada de trabalho da equipe (Check-in Global).
     * ROTA: /api/v1/equipe/start-shift (POST)
     * Requer: id_equipe, membros_ids (JSON), foto (multipart)
     */
    public function startShift()
    {
        try {
            $userId = AuthManager::getUserIdFromToken();
            $input = $_POST; // Assumindo que dados não-arquivo vêm via POST/Multipart

            // Validações (Exemplo)
            if (empty($input['id_equipe']) || empty($input['membros_ids'])) {
                throw new \Exception("Dados incompletos para iniciar a jornada.");
            }

            // Lógica para salvar a foto e obter o caminho
            // ... (Você já tem essa lógica em `performCheckin` ou `uploadOSPhoto`)

            // 1. REGISTRA NA TABELA DE JORNADAS
            $jornadaId = self::createJornadaHelper([ // Simulação da função de modelo
                'id_equipe' => (int)$input['id_equipe'],
                'membros_na_abertura' => $input['membros_ids'],
                'aberto_por_usuario_id' => $userId,
                'status' => 'ativo',
                // Aqui você pode adicionar a localização GPS e o link da foto de check-in
            ]);

            // 2. Resposta de Sucesso
            header('Content-Type: application/json');
            http_response_code(201);
            echo json_encode([
                'success' => true,
                'message' => 'Jornada iniciada com sucesso.',
                'jornada_id' => $jornadaId,
            ]);
            exit;
        } catch (\Exception $e) {
            header('Content-Type: application/json');
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit;
        }
    }

    /**
     * Finaliza a jornada de trabalho da equipe (Checkout Global).
     * ROTA: /api/v1/equipe/end-shift (POST)
     * Requer: id_jornada (o ID do turno ativo), observacao (opcional)
     */
    public function endShift()
    {
        try {
            $userId = AuthManager::getUserIdFromToken();
            $input = json_decode(file_get_contents('php://input'), true);

            // 1. Validações
            if (empty($input['id_jornada'])) {
                throw new \Exception("ID da jornada é obrigatório para o checkout.");
            }
            $jornadaId = (int)$input['id_jornada'];

            // 2. ATUALIZA A TABELA DE JORNADAS
            $success = self::updateJornadaHelper($jornadaId, [ // Simulação da função de modelo
                'data_fim_jornada' => date('Y-m-d H:i:s'),
                'fechado_por_usuario_id' => $userId,
                'status' => 'fechado',
            ]);

            if (!$success) {
                throw new \Exception("Falha ao finalizar jornada. Verifique se a jornada está ativa.");
            }

            // 3. Resposta de Sucesso
            header('Content-Type: application/json');
            http_response_code(200);
            echo json_encode([
                'success' => true,
                'message' => 'Fim da jornada de trabalho registrado com sucesso.',
                'jornada_id' => $jornadaId,
            ]);
            exit;
        } catch (\Exception $e) {
            header('Content-Type: application/json');
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit;
        }
    }

    /**
     * (HELPER) Insere um novo registro na tabela equipe_jornadas_trabalho.
     */
    private static function createJornadaHelper(array $data): int
    {
        try {
            $pdo = getDbConnection();
            $sql = "INSERT INTO equipe_jornadas_trabalho 
                        (id_equipe, membros_na_abertura, aberto_por_usuario_id, status)
                    VALUES 
                        (:id_equipe, :membros_na_abertura, :aberto_por_usuario_id, :status)";

            $stmt = $pdo->prepare($sql);
            $stmt->execute($data);
            return (int)$pdo->lastInsertId();
        } catch (PDOException $e) {
            error_log("ERRO AO CRIAR JORNADA: " . $e->getMessage());
            throw new \Exception("Falha ao registrar início da jornada no banco de dados.");
        }
    }

    /**
     * (HELPER) Atualiza o registro de jornada (fecha o turno).
     */
    private static function updateJornadaHelper(int $jornadaId, array $data): bool
    {
        try {
            $pdo = getDbConnection();
            $sql = "UPDATE equipe_jornadas_trabalho
                    SET data_fim_jornada = :data_fim_jornada,
                        fechado_por_usuario_id = :fechado_por_usuario_id,
                        status = :status
                    WHERE id = :id AND status = 'ativo'";

            $stmt = $pdo->prepare($sql);
            $params = array_merge($data, ['id' => $jornadaId]);
            $stmt->execute($params);

            // Retorna true se pelo menos uma linha foi afetada
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            error_log("ERRO AO ATUALIZAR JORNADA: " . $e->getMessage());
            return false;
        }
    }

    // =================================================================================
    // FUNÇÃO FINAL PARA PROCESSAR A FILA OFFLINE (apply-item)
    // =================================================================================
    /**
     * Adiciona um item (material avulso ou estrutura) à tabela de execução (Micro).
     * Esta é a função final para processar a fila offline.
     * ROTA ESPERADA: /api/v1/os/{id}/apply-item
     */
    public function applyItem($osId) // O nome agora é applyItem
    {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        header('Content-Type: application/json; charset=UTF-8');
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            http_response_code(200);
            exit();
        }

        try {
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido ou expirado.']);
                return;
            }
            if (empty($osId)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'ID da OS não fornecido.']);
                return;
            }

            $data = json_decode(file_get_contents('php://input'), true);
            $itemId = filter_var($data['item_id'] ?? null, FILTER_VALIDATE_INT);
            $itemType = trim($data['item_type'] ?? '');
            $quantity = filter_var($data['quantity'] ?? null, FILTER_VALIDATE_FLOAT);
            $observacao = trim($data['observacao'] ?? '');

            // Prepara a observação: se estiver vazia, usa NULL para o banco
            $observacao = empty($observacao) ? null : $observacao;

            if (!$itemId || empty($itemType) || $quantity === false || $quantity <= 0) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Dados do item inválidos (ID, Tipo ou Quantidade).']);
                return;
            }
            if ($itemType !== 'material' && $itemType !== 'estrutura') {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Tipo de item inválido.']);
                return;
            }

            if ($itemType === 'estrutura') {
                $quantity = (int)$quantity;
            }

            $pdo = getDbConnection();

            // 4. Inserir na tabela os_execucao_itens
            $sql = "INSERT INTO os_execucao_itens
                    (id_componente, id_item, tipo_item, quantidade_aplicada, observacao, id_usuario, timestamp_execucao)
                VALUES
                    (:osId, :itemId, :itemType, :quantity, :observacao, :userId, NOW())";

            $stmt = $pdo->prepare($sql);
            $success = $stmt->execute([
                'osId' => $osId,
                'itemId' => $itemId,
                'itemType' => $itemType,
                'quantity' => $quantity,
                'observacao' => $observacao,
                'userId' => $userId
            ]);

            if ($success) {
                // 5. Log de Atividades
                $itemNome = self::getItemNameForLog($pdo, $itemType, $itemId);
                $logMessage = "Aplicado: {$quantity}x {$itemNome}.";
                if ($observacao) {
                    $logMessage .= " Obs: {$observacao}";
                }

                $stmtStatus = $pdo->prepare("SELECT status FROM projeto_componentes WHERE id = :osId");
                $stmtStatus->execute(['osId' => $osId]);
                $currentStatus = $stmtStatus->fetchColumn() ?: 'em_execucao';

                self::logComponenteActivity($osId, $userId, null, 'ITEM_APLICADO_APP', $logMessage, null, null, $currentStatus, $currentStatus);

                http_response_code(201); // 201 Created
                echo json_encode(['success' => true, 'message' => 'Material aplicado registrado com sucesso!']);
            } else {
                throw new Exception('Falha ao registrar o material aplicado no banco de dados.');
            }
        } catch (\Throwable $e) {
            http_response_code(500);
            // MUITO IMPORTANTE: Mantenha este log para ver o erro EXATO do PDO
            error_log("ERRO FATAL EM applyItem: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao aplicar o item.']);
        }
    }


    // =================================================================================
    // CÓDIGO ANTIGO (Mantemos a função 'addItemToOS' com um 'exit' de sucesso 
    // para o caso de algum código antigo do Flutter ainda a chamar.)
    // =================================================================================
    /**
     * ROTA OBSOLETA - APONTAVA PARA O COMPONENTE_MATERIAIS_AVULSOS.
     * Agora apenas retorna sucesso e loga para não quebrar a fila.
     */
    public function addItemToOS($osId)
    {
        header('Content-Type: application/json');
        error_log("AVISO: Rota /add-item chamada. Usando fallback de sucesso. Por favor, atualize o Flutter para usar /apply-item.");

        http_response_code(200);
        echo json_encode(['success' => true, 'message' => 'Rota antiga desabilitada. Item considerado sincronizado.']);
        exit();
    }

    /**
     * (LÍDER) Reverte o status de uma OS de 'cancelado' para 'planejado' (ou 'em_andamento').
     * Exige uma justificativa obrigatória.
     */
    public function reactivateOS($osId)
    {
        header('Access-Control-Allow-Origin: *');
        header('Content-Type: application/json; charset=UTF-8');
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            http_response_code(200);
            exit();
        }

        try {
            $userId = AuthManager::getUserIdFromToken();
            if (!$userId) {
                http_response_code(401);
                echo json_encode(['success' => false, 'message' => 'Token inválido.']);
                return;
            }
            if (empty($osId)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'ID da OS não fornecido.']);
                return;
            }

            // 1. Obter Justificativa (Obrigatória)
            $data = json_decode(file_get_contents('php://input'), true);
            $observacao = trim($data['observacao'] ?? '');

            if (empty($observacao) || strlen($observacao) < 8) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Justificativa para reabertura é obrigatória (mín. 8 caracteres).']);
                return;
            }

            $pdo = getDbConnection();

            // 2. VERIFICAR STATUS ATUAL: SÓ PODE REATIVAR SE ESTIVER 'cancelado'
            $stmtStatus = $pdo->prepare("SELECT status FROM projeto_componentes WHERE id = :osId");
            $stmtStatus->execute(['osId' => $osId]);
            $currentStatus = $stmtStatus->fetchColumn();

            if ($currentStatus !== 'cancelado') {
                http_response_code(409); // Conflito
                echo json_encode(['success' => false, 'message' => 'A OS só pode ser reativada se estiver no status cancelado. Status atual: ' . $currentStatus]);
                return;
            }

            // 3. ATUALIZAR O STATUS DA OS para 'em_andamento' (Laranja)
            $newStatus = 'em_andamento';
            $sql = "UPDATE projeto_componentes
                    SET status = :newStatus, ultima_alteracao_por = :userId, data_ultima_alteracao = NOW()
                    WHERE id = :osId AND status = 'cancelado'";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['userId' => $userId, 'osId' => $osId, 'newStatus' => $newStatus]);

            if ($stmt->rowCount() > 0) {
                // 4. Logar a ação
                self::logComponenteActivity(
                    $osId,
                    $userId,
                    null,
                    'OS_REATIVADA_APP',
                    'Reativada após cancelamento. Motivo: ' . $observacao,
                    null,
                    null,
                    'cancelado',
                    $newStatus
                );

                http_response_code(200);
                echo json_encode(['success' => true, 'message' => 'OS reativada com sucesso! Voltando para ' . $newStatus, 'new_status' => $newStatus]);
            } else {
                throw new Exception('Falha ao reativar a OS (rowCount = 0).');
            }
        } catch (\Throwable $e) {
            http_response_code(500);
            error_log("ERRO FATAL em reactivateOS: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao reativar OS.']);
        }
    }

    public function handleSaveGenerico()
    {
        if (!AuthManager::validateSession()) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Sessão expirada.']);
            exit;
        }

        // 1. Pega o input (funciona para JSON e POST)
        $data = json_decode(file_get_contents('php://input'), true) ?? $_POST;

        // 2. Extrai a tabela e os campos/mapeamentos necessários
        //    O cliente precisa enviar estas chaves.
        $tableName = $data['table'] ?? null;

        // Mapeamento que o cliente deve enviar (dependendo da tabela)
        $mappings = [
            'perfil' => ['perfil' => 'perfil_nome'],
            'cidades' => ['id_estado' => 'estado_id', 'cidade' => 'nome_cidade'],
            'cnae' => ['cnae' => 'cnae_codigo', 'descricao' => 'cnae_descricao'],
            'setor_economico' => ['setor' => 'setor_nome'],
            'cargo' => ['cargo' => 'cargo_nome'],
            // Adicionar outros cadastros rápidos aqui...
        ];

        // Campo que deve ser checado como UNIQUE (o nome do input no JSON)
        $uniqueChecks = [
            'perfil' => 'perfil_nome',
            'cidades' => 'nome_cidade',
            'cnae' => 'cnae_codigo',
            'setor_economico' => 'setor_nome',
            'cargo' => 'cargo_nome',
        ];

        if (!isset($mappings[$tableName])) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Tabela de cadastro rápido inválida.']);
            exit;
        }

        // 3. Chama a função dinâmica
        ApiController::handleDynamicSave(
            $tableName,
            $mappings[$tableName],
            $uniqueChecks[$tableName]
        );
    }
    // >>> FIM DA NOVA FUNÇÃO <<<
}
