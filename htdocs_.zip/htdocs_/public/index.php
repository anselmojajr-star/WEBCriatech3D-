<?php

// --- MODO DEBUG (REMOVER DEPOIS) ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// -----------------------------------

mb_internal_encoding("UTF-8");

require_once __DIR__ . '/../config/constants.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

date_default_timezone_set('America/Sao_Paulo');

require_once __DIR__ . '/../vendor/autoload.php';

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->safeLoad(); // Novo!

require_once __DIR__ . '/../core/Router.php';

$router = new Router();

// Rotas de Autenticação e Dashboard
$router->add('GET', '/login', [AuthController::class, 'showLoginForm']);
$router->add('POST', '/login', [AuthController::class, 'processLogin']);
$router->add('GET', '/logout', [AuthController::class, 'logout']);
$router->add('GET', '/dashboard', [DashboardController::class, 'index']);

// Rotas do Módulo de Serviços
$router->add('GET', '/servicos', [ServicoController::class, 'index']);
$router->add('GET', '/servicos/novo', [ServicoController::class, 'create']);
$router->add('GET', '/servicos/editar/{id}', [ServicoController::class, 'edit']);
$router->add('POST', '/servicos/salvar', [ServicoController::class, 'store']);
$router->add('GET', '/servicos/excluir/{id}', [ServicoController::class, 'delete']);

// Rotas do Módulo de Estruturas
$router->add('GET', '/estruturas', [EstruturaController::class, 'index']);
$router->add('GET', '/estruturas/novo', [EstruturaController::class, 'create']);
$router->add('GET', '/estruturas/editar/{id}', [EstruturaController::class, 'edit']);
$router->add('POST', '/estruturas/salvar', [EstruturaController::class, 'store']);
$router->add('GET', '/estruturas/excluir/{id}', [EstruturaController::class, 'delete']);
$router->add('POST', '/estruturas/salvar-composicao-materiais', [EstruturaController::class, 'storeComposicaoMateriais']);
$router->add('POST', '/estruturas/salvar-composicao-subestruturas', [EstruturaController::class, 'storeComposicaoSubestruturas']);

// ADICIONE ESTA NOVA ROTA PARA O GERENCIADOR
$router->add('GET', '/gerente', [GerenteController::class, 'index']);
$router->add('POST', '/gerente/salvar-visibilidade-perfil', [GerenteController::class, 'storeVisibilidadePerfil']);
$router->add('POST', '/gerente/salvar-acoes-perfil', [GerenteController::class, 'storeAcoesPerfil']);
$router->add('POST', '/gerente/salvar-visibilidade-usuario', [GerenteController::class, 'storeVisibilidadeUsuario']);
$router->add('POST', '/gerente/salvar-acoes-usuario', [GerenteController::class, 'storeAcoesUsuario']);

// ADICIONE ESTAS NOVAS ROTAS PARA O CONTROLE DE ACESSO
$router->add('GET', '/controle-acesso', [ControleAcessoController::class, 'index']);
$router->add('POST', '/controle-acesso/salvar-regras-perfil', [ControleAcessoController::class, 'storeRegrasPerfil']);
$router->add('POST', '/controle-acesso/salvar-regras-usuario', [ControleAcessoController::class, 'storeRegrasUsuario']);
$router->add('POST', '/controle-acesso/resetar-regras-usuario', [ControleAcessoController::class, 'deleteRegrasUsuario']);


// ADICIONE ESTAS NOVAS ROTAS PARA A LIBERAÇÃO DE ACESSO
$router->add('GET', '/liberacao_acesso', [LiberacaoAcessoController::class, 'index']);
$router->add('GET', '/liberacao-acesso/liberar/{id}', [LiberacaoAcessoController::class, 'release']);
$router->add('GET', '/liberacao-acesso/dados', [LiberacaoAcessoController::class, 'getSessoesAjax']);

// ADICIONE ESTAS NOVAS ROTAS PARA PERFIS TEMPORÁRIOS
$router->add('GET', '/perfis_temporarios', [PerfilTemporarioController::class, 'index']);
$router->add('POST', '/perfis_temporarios/salvar', [PerfilTemporarioController::class, 'store']);
$router->add('GET', '/perfis_temporarios/excluir/{id}', [PerfilTemporarioController::class, 'delete']);

// ADICIONE ESTAS NOVAS ROTAS PARA ESPELHO DE PERMISSÕES
$router->add('GET', '/espelhar_permissoes', [GerenteController::class, 'showEspelharPermissoesForm']);
$router->add('POST', '/espelhar_permissoes/salvar', [GerenteController::class, 'storeEspelhamento']);

// --- ROTAS DA API ---
$router->add('GET', '/api/servicos/search', [ServicoController::class, 'search']);

// >>> ADICIONE ESTA ROTA FALTANTE AQUI <<<
$router->add('GET', '/api/estruturas/search', [EstruturaController::class, 'search']);

$router->add('GET', '/api/estruturas/search-materiais', [EstruturaController::class, 'searchMateriaisAjax']);
$router->add('GET', '/api/estruturas/search-estruturas', [EstruturaController::class, 'searchEstruturasAjax']);

// Roteamento para o Módulo de Colaboradores (Funcionário)
$router->add('GET', '/funcionario', [FuncionarioController::class, 'index']);
$router->add('GET', '/funcionario/novo', [FuncionarioController::class, 'create']);
$router->add('GET', '/funcionario/editar/{id}', [FuncionarioController::class, 'edit']);
$router->add('POST', '/funcionario/salvar', [FuncionarioController::class, 'store']);
$router->add('GET', '/funcionario/excluir/{id}', [FuncionarioController::class, 'delete']);
// Rota para a Funcionario API
$router->add('GET', '/api/funcionarios/search', [FuncionarioController::class, 'search']);

//Estudar Deletar

// --- ROTAS DE API GENÉRICA (DRY) ---
// Rota para carregar Cidades por Estado (usada por Funcionário/Empresa)
$router->add('GET', '/api/cidades-por-estado', [FuncionarioController::class, 'getCidadesPorEstadoApi']);
// Rota Genérica para SALVAR entidades pequenas (Cidade, Perfil, CNAE, Setor, Cargo, Medida)
$router->add('POST', '/api/salva-generico', [ApiController::class, 'handleSaveGenerico']);
//esse campo


// Roteamento para o Módulo de Material
$router->add('GET', '/material', [MaterialController::class, 'index']);
$router->add('GET', '/material/novo', [MaterialController::class, 'create']);
$router->add('GET', '/material/editar/{id}', [MaterialController::class, 'edit']);
$router->add('POST', '/material/salvar', [MaterialController::class, 'store']);
$router->add('GET', '/material/excluir/{id}', [MaterialController::class, 'delete']);

// Rota para a API de busca em tempo real
$router->add('GET', '/api/materiais/search', [MaterialController::class, 'search']);

// Roteamento para o Módulo de Empresa
$router->add('GET', '/empresa', [EmpresaController::class, 'index']);
$router->add('GET', '/empresa/novo', [EmpresaController::class, 'create']);
$router->add('GET', '/empresa/editar/{id}', [EmpresaController::class, 'edit']);
$router->add('POST', '/empresa/salvar', [EmpresaController::class, 'store']);
$router->add('GET', '/empresa/excluir/{id}', [EmpresaController::class, 'delete']);

// Rota para a API de busca em tempo real
$router->add('GET', '/api/empresas/search', [EmpresaController::class, 'search']);

// Roteamento para o Módulo de Contratos
$router->add('GET', '/contratos', [ContratoController::class, 'index']);
$router->add('GET', '/contratos/novo', [ContratoController::class, 'create']);
$router->add('GET', '/contratos/editar/{id}', [ContratoController::class, 'edit']);
$router->add('POST', '/contratos/salvar', [ContratoController::class, 'store']);
$router->add('GET', '/contratos/excluir/{id}', [ContratoController::class, 'delete']);

// Rota para a API de busca em tempo real
$router->add('GET', '/api/contratos/search', [ContratoController::class, 'search']);

// Roteamento para o Módulo de Projetos
$router->add('GET', '/projetos', [ProjetoController::class, 'index']);
$router->add('GET', '/projetos/novo', [ProjetoController::class, 'create']);
$router->add('GET', '/projetos/editar/{id}', [ProjetoController::class, 'edit']);
$router->add('POST', '/projetos/salvar', [ProjetoController::class, 'store']);
$router->add('GET', '/projetos/excluir/{id}', [ProjetoController::class, 'delete']);
// Rota para ler o DXF e devolver a lista de blocos encontrados (Módulo de Projetos)
$router->add('POST', '/api/projetos/analisar-dxf', [ProjetoController::class, 'analisarDxf']);
// Rota para processar o bloco escolhido e salvar no banco (Módulo de Projetos)
$router->add('POST', '/api/projetos/processar-dxf', [ProjetoController::class, 'processarDxf']);


// Rota para a API de busca em tempo real
$router->add('GET', '/api/projetos/search', [ProjetoController::class, 'search']);
$router->add('GET', '/api/projetos/equipes-por-lider', [ProjetoController::class, 'apiGetEquipesPorLider']);

// Roteamento para o Módulo de Módulos
$router->add('GET', '/modulos', [ModuloController::class, 'index']);
$router->add('GET', '/modulos/novo', [ModuloController::class, 'create']);
$router->add('GET', '/modulos/editar/{id}', [ModuloController::class, 'edit']);
$router->add('POST', '/modulos/salvar', [ModuloController::class, 'store']);
$router->add('GET', '/modulos/excluir/{id}', [ModuloController::class, 'delete']);

// Rota para a API de busca em tempo real
$router->add('GET', '/api/modulos/search', [ModuloController::class, 'search']);

// Rotas para o Módulo de Equipes
$router->add('GET', '/equipes', [EquipeController::class, 'index']);
$router->add('GET', '/equipes/novo', [EquipeController::class, 'create']);
$router->add('GET', '/equipes/editar/{id}', [EquipeController::class, 'edit']);
$router->add('POST', '/equipes/salvar', [EquipeController::class, 'store']);
$router->add('GET', '/equipes/excluir/{id}', [EquipeController::class, 'delete']);
$router->add('GET', '/api/equipes/search', [EquipeController::class, 'search']);
$router->add('POST', '/equipes/criar-login-app', [EquipeController::class, 'storeAppLogin']);

// Rotas do NOVO MÓDULO: Acompanhamento da Obra
$router->add('GET', '/acompanhamento', [AcompanhamentoController::class, 'index']); // Lista de Projetos (Visão App)
$router->add('GET', '/acompanhamento/mapa/{id}', [AcompanhamentoController::class, 'mapa']); // Mapa do Projeto
$router->add('GET', '/acompanhamento/details/{id}', [AcompanhamentoController::class, 'details']); // Relatório Detalhado da OS
$router->add('GET', '/api/acompanhamento/search-projetos', [AcompanhamentoController::class, 'searchProjetos']); // Nova API de busca

// Rotas 
$router->add('POST', '/api/v1/login', [ApiController::class, 'loginApp']);
$router->add('GET', '/api/v1/projetos', [ApiController::class, 'getProjetosApp']);
$router->add('GET', '/api/v1/projects/{id}/markers', [ApiController::class, 'getProjectMarkers']);
$router->add('POST', '/api/v1/os/{id}/liberar', [ApiController::class, 'liberarOS']);
$router->add('GET', '/api/v1/os/{id}/details', [ApiController::class, 'getOSDetails']);
$router->add('POST', '/api/v1/os/{id}/upload-photo', [ApiController::class, 'uploadOSPhoto']);
$router->add('POST', '/api/v1/os/{id}/update-position', [ApiController::class, 'updateOSPosition']);
//$router->add('POST', '/api/v1/os/{id}/add-item', [ApiController::class, 'addItemToOS']);
$router->add('GET', '/api/v1/get-all-items', [ApiController::class, 'getAllItemsApp']);
$router->add('GET', '/api/v1/search-items', [ApiController::class, 'searchItemsApp']);
$router->add('POST', '/api/v1/os/{osId}/item/{compItemId}/update-quantity', [ApiController::class, 'updateOSItemQuantity']);
$router->add('POST', '/api/v1/os/{osId}/item/{compItemId}/remove', [ApiController::class, 'removeOSItem']);
$router->add('POST', '/api/v1/os/{id}/cancel', [ApiController::class, 'cancelOS']);
$router->add('POST', '/api/v1/checkin', [ApiController::class, 'performCheckin']);
$router->add('POST', '/api/v1/os/{id}/start', [ApiController::class, 'startExecution']);
//$router->add('POST', '/api/v1/os/{id}/apply-item', [ApiController::class, 'applyItemToOS']);
$router->add('POST', '/api/v1/os/{id}/finish-incomplete', [ApiController::class, 'finishIncomplete']);
$router->add('POST', '/api/v1/os/{id}/complete', [ApiController::class, 'completeOS']);
$router->add('POST', '/api/v1/os/{id}/approve', [ApiController::class, 'approveOS']);
$router->add('POST', '/api/v1/os/{id}/reject', [ApiController::class, 'rejectOS']);
$router->add('POST', '/api/v1/logout', [AuthController::class, 'apiLogout']);
$router->add('POST', '/api/v1/equipe/start-shift', [ApiController::class, 'startShift']);
$router->add('POST', '/api/v1/equipe/end-shift', [ApiController::class, 'endShift']);
$router->add('POST', '/api/v1/os/{id}/apply-item', [ApiController::class, 'applyItem']);
$router->add('POST', '/api/v1/os/{id}/reactivate', [ApiController::class, 'reactivateOS']);

// Captura e processa a URL
$uri = strtok($_SERVER['REQUEST_URI'], '?');
$uri = str_replace(BASE_PATH, '', $uri);

// 1. Verifica se é API de Autenticação
if ($uri === '/api/auth') {
    require_once __DIR__ . '/../api/auth.php';
    exit();
}

// --- AQUI É A MUDANÇA ---

// 2. Verifica se é a Página Inicial (Raiz)
// Se a URI for vazia ou apenas uma barra, carregamos o Site Institucional
if ($uri === '/' || empty($uri)) {
    require __DIR__ . '/index.html'; // Carrega seu site novo
    exit; // Encerra o script para não carregar o sistema atrás
}

// 3. Se não for a Home, continua o fluxo normal
if (empty($uri)) {
    $uri = '/login';
}

$router->dispatch($uri, $_SERVER['REQUEST_METHOD']);
