<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-edit"></i> <?= $isEdit ? 'Editar Empresa' : 'Nova Empresa' ?></h3>
        <div class="card-tools">
            <a href="<?= BASE_PATH ?>/empresa" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Voltar à Lista</a>
        </div>
    </div>
    <div class="card-body">
        <div class="card card-primary card-tabs">
            <div class="card-header p-0 pt-1">
                <ul class="nav nav-tabs" id="empresaTabs" role="tablist">
                    <li class="nav-item"><a class="nav-link active" id="cadastrais-tab" data-toggle="pill" href="#cadastrais" role="tab">Dados Cadastrais</a></li>
                    <?php if ($isEdit): ?>
                        <li class="nav-item"><a class="nav-link" id="endereco-tab" data-toggle="pill" href="#endereco" role="tab">Endereço</a></li>
                        <li class="nav-item"><a class="nav-link" id="atividade-tab" data-toggle="pill" href="#atividade" role="tab">Atividade Econômica</a></li>
                        <li class="nav-item"><a class="nav-link" id="contatos-tab" data-toggle="pill" href="#contatos" role="tab">Contatos</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="tab-content mt-4">
                <div class="tab-pane fade show active" id="cadastrais" role="tabpanel">
                    <form action="<?= BASE_PATH ?>/empresa/salvar" method="post">
                        <input type="hidden" name="action" value="salvarDadosCadastrais">
                        <input type="hidden" name="id_empresa" value="<?= $empresa['id'] ?? '' ?>">
                        <input type="hidden" name="active_tab" value="cadastrais">
                        <div class="row">
                            <div class="col-md-6 form-group"><label>Razão Social</label><input type="text" class="form-control" name="razao_social" value="<?= htmlspecialchars($empresa['razao_social'] ?? '') ?>" required></div>
                            <div class="col-md-6 form-group"><label>Nome Fantasia</label><input type="text" class="form-control" name="nome_fantasia" value="<?= htmlspecialchars($empresa['nome_fantasia'] ?? '') ?>" required></div>
                            <div class="col-md-6 form-group"><label>CNPJ</label><input type="text" class="form-control" name="cnpj" value="<?= htmlspecialchars($empresa['cnpj'] ?? '') ?>" required></div>
                            <div class="col-md-6 form-group"><label>Site</label><input type="url" class="form-control" name="site" value="<?= htmlspecialchars($empresa['site'] ?? '') ?>"></div>
                            <div class="col-md-6 form-group"><label>Email Corporativo</label><input type="email" class="form-control" name="email" value="<?= htmlspecialchars($empresa['email'] ?? '') ?>"></div>
                            <div class="col-md-6 form-group"><label>Telefone Principal</label><input type="tel" class="form-control" name="telefone" value="<?= htmlspecialchars($empresa['telefone'] ?? '') ?>"></div>
                        </div>
                        <div class="card-footer bg-white pl-0"><button type="submit" class="btn btn-primary">Salvar Dados Cadastrais</button></div>
                    </form>
                </div>
                <?php if ($isEdit): ?>
                    <div class="tab-pane fade" id="endereco" role="tabpanel">
                        <form action="<?= BASE_PATH ?>/empresa/salvar" method="post" id="form-endereco">
                            <input type="hidden" name="action" value="salvarEndereco">
                            <input type="hidden" name="id_empresa" value="<?= $empresa['id'] ?? '' ?>">
                            <input type="hidden" name="active_tab" value="endereco">

                            <div class="row">
                                <div class="col-md-4 form-group"><label>CEP</label><input type="text" class="form-control" name="cep" value="<?= htmlspecialchars($endereco['cep'] ?? '') ?>"></div>
                                <div class="col-md-8 form-group"><label>Logradouro</label><input type="text" class="form-control" name="logradouro" value="<?= htmlspecialchars($endereco['logradouro'] ?? '') ?>"></div>
                                <div class="col-md-4 form-group"><label>Número</label><input type="text" class="form-control" name="numero" value="<?= htmlspecialchars($endereco['numero'] ?? '') ?>"></div>
                                <div class="col-md-8 form-group"><label>Complemento</label><input type="text" class="form-control" name="complemento" value="<?= htmlspecialchars($endereco['complemento'] ?? '') ?>"></div>
                                <div class="col-md-4 form-group"><label>Bairro</label><input type="text" class="form-control" name="bairro" value="<?= htmlspecialchars($endereco['bairro'] ?? '') ?>"></div>

                                <div class="col-md-4 form-group">
                                    <label>Estado</label>
                                    <select class="form-control" name="id_estado" id="estado_select">
                                        <option value="">Selecione</option>
                                        <?php foreach ($data['estados'] as $estado): ?>
                                            <option value="<?= $estado['id'] ?>" <?= ($endereco['id_estado'] ?? '') == $estado['id'] ? 'selected' : '' ?>><?= htmlspecialchars($estado['nome']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-4 form-group">
                                    <label>Cidade</label>
                                    <div class="input-group">
                                        <select class="form-control" name="id_cidade" id="cidade_select" data-cidade-atual-id="<?= $endereco['id_cidade'] ?? '' ?>">
                                            <option value="">Selecione um Estado</option>
                                        </select>
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-success" type="button" id="btnNovaCidade" data-toggle="modal" data-target="#modalNovaCidade" disabled>+</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer bg-white pl-0"><button type="submit" class="btn btn-primary">Salvar Endereço</button></div>
                        </form>

                        <div class="modal fade" id="modalNovaCidade" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Cadastrar Nova Cidade</h5>
                                        <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label>Nome da Cidade</label>
                                            <input type="text" id="inputNomeNovaCidade" class="form-control">
                                        </div>
                                        <div id="novaCidadeStatus"></div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                        <button type="button" class="btn btn-primary" id="btnSalvarNovaCidade">Salvar Cidade</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="atividade" role="tabpanel">
                        <form action="<?= BASE_PATH ?>/empresa/salvar" method="post">
                            <input type="hidden" name="action" value="salvarAtividade">
                            <input type="hidden" name="id_empresa" value="<?= $empresa['id'] ?? '' ?>">
                            <input type="hidden" name="active_tab" value="atividade">
                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label>CNAE Principal</label>
                                    <div class="input-group">
                                        <select class="form-control" name="id_cnae" id="cnae_select" required>
                                            <option value="">Selecione</option>
                                            <?php foreach ($data['cnaes'] as $cnae): ?>
                                                <option value="<?= $cnae['id'] ?>" <?= ($atividade['id_cnae'] ?? '') == $cnae['id'] ? 'selected' : '' ?>><?= htmlspecialchars($cnae['cnae'] . ' - ' . $cnae['descricao']) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-success" type="button" data-toggle="modal" data-target="#modalNovoCnae">+</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Setor Econômico</label>
                                    <div class="input-group">
                                        <select class="form-control" name="id_set_eco" id="setor_select" required>
                                            <option value="">Selecione</option>
                                            <?php foreach ($data['setores'] as $setor): ?>
                                                <option value="<?= $setor['id'] ?>" <?= ($atividade['id_set_eco'] ?? '') == $setor['id'] ? 'selected' : '' ?>><?= htmlspecialchars($setor['setor']) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-success" type="button" data-toggle="modal" data-target="#modalNovoSetor">+</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 form-group">
                                    <label>Descrição da Atividade (personalizada)</label>
                                    <textarea class="form-control" name="descricao_atividade" rows="3"><?= htmlspecialchars($atividade['descrição'] ?? '') ?></textarea>
                                </div>
                            </div>
                            <div class="card-footer bg-white pl-0"><button type="submit" class="btn btn-primary">Salvar Atividade Econômica</button></div>
                        </form>

                        <div class="modal fade" id="modalNovoCnae" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Cadastrar Novo CNAE</h5><button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label>Código CNAE</label>
                                            <input type="text" id="inputNovoCnaeCodigo" class="form-control" placeholder="Ex: 6201-5/00">
                                        </div>
                                        <div class="form-group">
                                            <label>Descrição do CNAE</label>
                                            <input type="text" id="inputNovoCnaeDescricao" class="form-control">
                                        </div>
                                        <div id="novoCnaeStatus"></div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                        <button type="button" class="btn btn-primary" id="btnSalvarNovoCnae">Salvar CNAE</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="modalNovoSetor" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Cadastrar Novo Setor</h5><button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label>Nome do Setor</label>
                                            <input type="text" id="inputNovoSetorNome" class="form-control" placeholder="Ex: Tecnologia">
                                        </div>
                                        <div id="novoSetorStatus"></div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                        <button type="button" class="btn btn-primary" id="btnSalvarNovoSetor">Salvar Setor</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="contatos" role="tabpanel">
                        <form action="<?= BASE_PATH ?>/empresa/salvar" method="post">
                            <input type="hidden" name="action" value="salvarContato">
                            <input type="hidden" name="id_empresa" value="<?= $empresa['id'] ?? '' ?>">
                            <input type="hidden" name="active_tab" value="contatos">

                            <div class="row">
                                <div class="col-md-6 form-group">
                                    <label>Nome do Responsável</label>
                                    <input type="text" class="form-control" name="nome_responsavel" value="<?= htmlspecialchars($contato['Nome'] ?? '') ?>" required>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Cargo do Responsável</label>
                                    <div class="input-group">
                                        <select class="form-control" name="id_cargo" id="cargo_select" required>
                                            <option value="">Selecione</option>
                                            <?php foreach ($data['cargos'] as $cargo): ?>
                                                <option value="<?= $cargo['id'] ?>" <?= ($contato['id_cargo'] ?? '') == $cargo['id'] ? 'selected' : '' ?>><?= htmlspecialchars($cargo['cargo']) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-success" type="button" data-toggle="modal" data-target="#modalNovoCargo">+</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Telefone de Contato</label>
                                    <input type="tel" class="form-control" name="telefone_contato" value="<?= htmlspecialchars($contato['telefone'] ?? '') ?>">
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Email do Responsável</label>
                                    <input type="email" class="form-control" name="email_responsavel" value="<?= htmlspecialchars($contato['email'] ?? '') ?>">
                                </div>
                            </div>
                            <div class="card-footer bg-white pl-0"><button type="submit" class="btn btn-primary">Salvar Contato</button></div>
                        </form>

                        <div class="modal fade" id="modalNovoCargo" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Cadastrar Novo Cargo</h5>
                                        <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label>Nome do Cargo</label>
                                            <input type="text" id="inputNovoCargoNome" class="form-control" placeholder="Ex: Diretor(a)">
                                        </div>
                                        <div id="novoCargoStatus"></div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                        <button type="button" class="btn btn-primary" id="btnSalvarNovoCargo">Salvar Cargo</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>