<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<?php
// views/dashboard/index.php (Versão Correta e Limpa)
// ATUALIZADO para exibir KPIs e Gráficos

$username = htmlspecialchars(ucfirst($_SESSION['username'] ?? 'Usuário'));

// Verifica se os dados do dashboard foram carregados com sucesso
if (empty($dashboardData) || !isset($dashboardData['statusCounts'])) {
?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Bem-vindo, <?php echo $username; ?>!</h5>
                    <p class="card-text">
                        Ocorreu um erro ao carregar os dados de produção. Por favor, contate o administrador.
                    </p>
                </div>
            </div>
        </div>
    </div>
<?php
} else {
    // Processa os dados recebidos do Controller
    $planejado     = $dashboardData['statusCounts']['planejado'] ?? 0;
    $emExecucao    = $dashboardData['statusCounts']['em_execucao'] ?? 0;
    $concluido     = $dashboardData['statusCounts']['concluido'] ?? 0; // Aguardando validação
    $validado      = $dashboardData['statusCounts']['validado'] ?? 0;
    $cancelado     = $dashboardData['statusCounts']['cancelado'] ?? 0;
    $concluidoHoje = $dashboardData['concluidoHoje'] ?? 0;
    $producaoSemanal = $dashboardData['producaoSemanal'] ?? [];

    // Processa os novos dados de projetos
    $progressoProjetos = $dashboardData['progressoProjetos'] ?? [];
?>
    <div class="row">
        <div class="col-lg-12">
            <h5 class="mb-3">Bem-vindo, <?php echo $username; ?>!</h5>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
                <div class="inner">
                    <h3><?php echo $emExecucao; ?></h3>
                    <p>OS em Execução</p>
                </div>
                <div class="icon">
                    <i class="fas fa-running"></i>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-success">
                <div class="inner">
                    <h3><?php echo $concluidoHoje; ?></h3>
                    <p>OS Concluídas Hoje</p>
                </div>
                <div class="icon">
                    <i class="fas fa-check"></i>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-warning">
                <div class="inner">
                    <h3><?php echo $concluido; ?></h3>
                    <p>Aguardando Validação</p>
                </div>
                <div class="icon">
                    <i class="fas fa-clipboard-list"></i>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-6">
            <div class="small-box bg-primary">
                <div class="inner">
                    <h3><?php echo $planejado; ?></h3>
                    <p>OS Planejadas</p>
                </div>
                <div class="icon">
                    <i class="fas fa-calendar-alt"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-5">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Status Geral das OS</h3>
                </div>
                <div class="card-body">
                    <canvas id="statusOsChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
                </div>
            </div>
        </div>

        <div class="col-md-7">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Produção (Últimos 7 dias)</h3>
                </div>
                <div class="card-body">
                    <canvas id="producaoSemanalChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Progresso dos Projetos</h3>
                </div>
                <div class="card-body">
                    <div class="chart">
                        <canvas id="progressoProjetosChart" style="min-height: 300px; height: 300px; max-height: 300px; max-width: 100%;"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script>
        document.addEventListener("DOMContentLoaded", function() {

            // --- Funçã para garantir ticks inteiros no eixo Y
            const integerTicks = {
                beginAtZero: true,
                callback: function(value) {
                    if (Number.isInteger(value)) {
                        return value;
                    }
                },
                stepSize: 1
            };

            // --- DADOS Gráfico de Pizza (Status Geral) ---
            const statusData = {
                labels: ['Planejado', 'Em Execução', 'Aguard. Validação', 'Validado', 'Cancelado'],
                datasets: [{
                    data: [
                        <?php echo $planejado; ?>,
                        <?php echo $emExecucao; ?>,
                        <?php echo $concluido; ?>,
                        <?php echo $validado; ?>,
                        <?php echo $cancelado; ?>
                    ],
                    backgroundColor: ['#007bff', '#17a2b8', '#ffc107', '#28a745', '#dc3545'],
                }]
            };

            // --- Renderiza Gráfico de Pizza ---
            const ctxPie = document.getElementById('statusOsChart').getContext('2d');
            new Chart(ctxPie, {
                type: 'doughnut',
                data: statusData,
                options: {
                    maintainAspectRatio: false,
                    responsive: true,
                    legend: {
                        position: 'right',
                    }
                }
            });

            // --- DADOS Gráfico de Barras (Produção Semanal) ---
            const producaoPhpData = <?php echo json_encode($producaoSemanal); ?>;
            const producaoLabels = producaoPhpData.map(item => {
                const parts = item.dia.split('-');
                return parts[2] + '/' + parts[1];
            });
            const producaoValores = producaoPhpData.map(item => item.total);

            const barData = {
                labels: producaoLabels,
                datasets: [{
                    label: 'OS Concluídas',
                    backgroundColor: 'rgba(40, 167, 69, 0.8)',
                    borderColor: 'rgba(40, 167, 69, 1)',
                    borderWidth: 1,
                    data: producaoValores
                }]
            };

            // --- Renderiza Gráfico de Barras (Produção Semanal) ---
            const ctxBar = document.getElementById('producaoSemanalChart').getContext('2d');
            new Chart(ctxBar, {
                type: 'bar',
                data: barData,
                options: {
                    maintainAspectRatio: false,
                    responsive: true,
                    scales: {
                        yAxes: [{
                            ticks: integerTicks
                        }]
                    },
                    legend: {
                        display: false
                    }
                }
            });

            // =================================================================
            // NOVOS DADOS: Gráfico de Barras (Progresso dos Projetos)
            // =================================================================
            const projetosPhpData = <?php echo json_encode($progressoProjetos); ?>;

            const projetoLabels = projetosPhpData.map(p => p.nome_projeto);
            const escopoData = projetosPhpData.map(p => p.escopo_valido);
            const validadoData = projetosPhpData.map(p => p.os_validadas);

            const projetosBarData = {
                labels: projetoLabels,
                datasets: [{
                        label: 'Escopo Válido (Total OS - Canceladas)',
                        backgroundColor: 'rgba(0, 123, 255, 0.8)', // Azul
                        data: escopoData
                    },
                    {
                        label: 'OS Validadas (Progresso)',
                        backgroundColor: 'rgba(40, 167, 69, 0.8)', // Verde
                        data: validadoData
                    }
                ]
            };

            // --- Renderiza Gráfico de Barras (Progresso dos Projetos) ---
            const ctxProjetosBar = document.getElementById('progressoProjetosChart').getContext('2d');
            new Chart(ctxProjetosBar, {
                type: 'bar',
                data: projetosBarData,
                options: {
                    maintainAspectRatio: false,
                    responsive: true,
                    scales: {
                        yAxes: [{
                            ticks: integerTicks
                        }],
                        xAxes: [{
                            ticks: {
                                autoSkip: false
                            }
                        }] // Tenta não pular nomes de projeto
                    },
                    legend: {
                        display: true,
                        position: 'top'
                    }
                }
            });

        });
    </script>
<?php
} // Fim do 'else' que verifica $dashboardData
?>