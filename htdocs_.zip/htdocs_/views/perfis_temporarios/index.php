<div class="card card-primary card-outline">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-user-clock"></i> Atribuir Perfil Temporário</h3>
    </div>
    <form action="<?= BASE_PATH ?>/perfis_temporarios/salvar" method="POST">
        <div class="card-body">
            <div class="row">
                <div class="col-md-3 form-group">
                    <label for="id_usuario">Usuário</label>
                    <select name="id_usuario" id="id_usuario" class="form-control" required>
                        <option value="">Selecione...</option>
                        <?php foreach ($usuarios as $usuario): ?>
                            <option value="<?= $usuario['id'] ?>"><?= htmlspecialchars($usuario['username']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3 form-group">
                    <label for="id_perfil">Perfil a ser Concedido</label>
                    <select name="id_perfil" id="id_perfil" class="form-control" required>
                        <option value="">Selecione...</option>
                        <?php foreach ($perfis as $perfil): ?>
                            <option value="<?= $perfil['id'] ?>"><?= htmlspecialchars($perfil['perfil']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3 form-group">
                    <label for="data_inicio">Válido De</label>
                    <input type="date" name="data_inicio" id="data_inicio" class="form-control" required>
                </div>
                <div class="col-md-3 form-group">
                    <label for="data_fim">Válido Até</label>
                    <input type="date" name="data_fim" id="data_fim" class="form-control" required>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-success">Salvar Atribuição</button>
        </div>
    </form>
</div>

<div class="card mt-4">
    <div class="card-header">
        <h3 class="card-title"><i class="fas fa-list"></i> Atribuições Ativas e Expiradas</h3>
    </div>
    <div class="card-body p-0">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Usuário</th>
                    <th>Perfil Concedido</th>
                    <th>Início</th>
                    <th>Fim</th>
                    <th>Status</th>
                    <th>Atribuído Por</th>
                    <th class="text-center">Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($atribuicoes)): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">Nenhuma atribuição temporária encontrada.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($atribuicoes as $atb): ?>
                        <tr>
                            <td><?= htmlspecialchars($atb['nome_usuario']) ?></td>
                            <td><?= htmlspecialchars($atb['nome_perfil']) ?></td>
                            <td><?= date('d/m/Y', strtotime($atb['data_inicio'])) ?></td>
                            <td><?= date('d/m/Y', strtotime($atb['data_fim'])) ?></td>
                            <td>
                                <?php if (date('Y-m-d') >= $atb['data_inicio'] && date('Y-m-d') <= $atb['data_fim']): ?>
                                    <span class="badge badge-success">Ativo</span>
                                <?php else: ?>
                                    <span class="badge badge-secondary">Expirado</span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($atb['nome_atribuidor'] ?? 'N/A') ?></td>
                            <td class="text-center">
                                <a href="<?= BASE_PATH ?>/perfis_temporarios/excluir/<?= $atb['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja remover esta atribuição?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>