<?php // views/partials/tabela_horarios.php 
?>
<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th width="150px">Dia da Semana</th>
            <th class="text-center" width="100px">Acesso Liberado</th>
            <th>1º Turno (Início - Fim)</th>
            <th>2º Turno (Início - Fim)</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($diasDaSemana as $dia): ?>
            <?php $regra = $regrasAtuais[$dia] ?? []; ?>
            <tr>
                <td><?= ucfirst($dia) ?></td>
                <td class="text-center">
                    <input type="checkbox" name="regras[<?= $dia ?>][acesso_liberado]" <?= !empty($regra['acesso_liberado']) ? 'checked' : '' ?>>
                </td>
                <td>
                    <div class="input-group">
                        <input type="time" name="regras[<?= $dia ?>][hora_inicio_1]" class="form-control" value="<?= htmlspecialchars($regra['hora_inicio_1'] ?? '') ?>">
                        <input type="time" name="regras[<?= $dia ?>][hora_fim_1]" class="form-control" value="<?= htmlspecialchars($regra['hora_fim_1'] ?? '') ?>">
                    </div>
                </td>
                <td>
                    <div class="input-group">
                        <input type="time" name="regras[<?= $dia ?>][hora_inicio_2]" class="form-control" value="<?= htmlspecialchars($regra['hora_inicio_2'] ?? '') ?>">
                        <input type="time" name="regras[<?= $dia ?>][hora_fim_2]" class="form-control" value="<?= htmlspecialchars($regra['hora_fim_2'] ?? '') ?>">
                    </div>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<div class="card-footer bg-white mt-3 pl-0">
    <button type="submit" class="btn btn-success">Salvar Horários</button>
</div>