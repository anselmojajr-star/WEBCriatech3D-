<footer class="main-footer">
    <strong>&copy; <?php echo date('Y'); ?> Tectheta System. V-6.2 </strong> Todos os direitos reservados.
</footer>