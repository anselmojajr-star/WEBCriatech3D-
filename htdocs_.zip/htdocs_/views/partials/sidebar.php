<?php
// views/partials/sidebar.php (Versão Final e Dinâmica)

if (!isset($menuItems)) {
    // Garante que os itens de menu sejam carregados caso o layout seja chamado de forma inesperada.
    $menuItems = MenuPermissionManager::getVisibleMenuItems($_SESSION['user_id'] ?? 0);
}
?>
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="<?= BASE_PATH ?>/dashboard" class="brand-link">
        <img src="<?= BASE_PATH ?>/assets/img/logo_C_F.png" alt="Logo Tectheta" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">Tectheta</span>
    </a>
    <div class="sidebar">
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">

                <?php foreach ($menuItems as $item): ?>
                    <?php
                    $hasSubmenu = !empty($item['submenus']);

                    // LÓGICA INTELIGENTE: Transforma a rota do banco (ex: 'servicos.php') na nova URL (ex: '/servicos')
                    $rotaLimpa = str_replace('.php', '', $item['rota']);
                    $link = $hasSubmenu ? '#' : BASE_PATH . '/' . htmlspecialchars($rotaLimpa);
                    ?>
                    <li class="nav-item <?= $hasSubmenu ? 'has-treeview' : '' // A classe 'menu-open' foi removida para que os menus comecem fechados 
                                        ?>">
                        <a href="<?= $link ?>" class="nav-link">
                            <i class="nav-icon <?php echo htmlspecialchars($item['icone']); ?>"></i>
                            <p>
                                <?php echo htmlspecialchars($item['nome']); ?>
                                <?php if ($hasSubmenu): ?>
                                    <i class="right fas fa-angle-left"></i>
                                <?php endif; ?>
                            </p>
                        </a>
                        <?php if ($hasSubmenu): ?>
                            <ul class="nav nav-treeview">
                                <?php foreach ($item['submenus'] as $submenu): ?>
                                    <?php
                                    $submenuRotaLimpa = str_replace('.php', '', $submenu['rota']);
                                    $submenuLink = BASE_PATH . '/' . htmlspecialchars($submenuRotaLimpa);
                                    ?>
                                    <li class="nav-item">
                                        <a href="<?= $submenuLink ?>" class="nav-link">
                                            <i class="far fa-circle nav-icon"></i>
                                            <p><?php echo htmlspecialchars($submenu['nome']); ?></p>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>

            </ul>
        </nav>
    </div>
</aside>