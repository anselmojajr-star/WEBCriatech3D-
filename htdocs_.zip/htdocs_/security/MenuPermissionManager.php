<?php
// security/MenuPermissionManager.php

class MenuPermissionManager
{
    /**
     * Busca os itens de menu visíveis para um usuário, aplicando a nova hierarquia de permissões.
     * VERSÃO CORRIGIDA: Usa $_SESSION['perfis'] para definir o perfil ativo, garantindo que o temporário prevaleça.
     *
     * @param int $userId O ID do usuário logado.
     * @return array Um array hierárquico com os itens de menu permitidos.
     */
    public static function getVisibleMenuItems(int $userId): array
    {
        try {
            $pdo = getDbConnection();

            // [CORREÇÃO CRÍTICA]: Usamos a sessão para obter o perfil ativo (temporário ou padrão).
            // A lógica do AuthManager garante que $_SESSION['perfis'] tem a prioridade correta.
            $perfis = $_SESSION['perfis'] ?? [];

            if (empty($perfis)) {
                return self::getDefaultMenu();
            }

            // O perfil base para permissão é sempre o primeiro ID na lista.
            $perfilAtivoId = $perfis[0];

            // REGRA 1: Administrador (perfil 4) vê tudo. 
            // O perfil 4 só deve estar na sessão se for o perfil ativo (temporário ou padrão).
            if (in_array(4, $perfis)) {
                $sql = "SELECT * FROM modulos WHERE status <> 'desativado' AND (tipo_menu = 'menu_principal' OR tipo_menu = 'submenu_item') ORDER BY ordem ASC, nome ASC";
                $stmt = $pdo->prepare($sql);
                $stmt->execute();
            } else {
                // --- LÓGICA PARA USUÁRIOS NORMAIS ---
                // O primeiro placeholder (?) usa o $perfilAtivoId para o JOIN de permissão de Perfil.
                $sql = "
                    SELECT DISTINCT
                        m.*
                    FROM
                        modulos m
                    LEFT JOIN (
                        -- Busca permissões APENAS para o perfil ATIVO (que deve ser o ID 5 neste caso)
                        SELECT pmp.id_modulo
                        FROM perfil_modulo_permissao pmp
                        WHERE pmp.id_perfil = ? AND pmp.visualizar = 1
                    ) AS profile_perms ON m.id = profile_perms.id_modulo
                    LEFT JOIN (
                        -- Busca sobreposições de usuário (com datas de validade)
                        SELECT ump.id_modulo, ump.permitido
                        FROM usuario_modulo_permissao ump
                        WHERE ump.id_usuario = ?
                          AND (ump.data_inicio_validade IS NULL OR CURDATE() >= ump.data_inicio_validade)
                          AND (ump.data_fim_validade IS NULL OR CURDATE() <= ump.data_fim_validade)
                    ) AS user_perms ON m.id = user_perms.id_modulo
                    WHERE
                        m.status = 'liberado'
                        AND (m.tipo_menu = 'menu_principal' OR m.tipo_menu = 'submenu_item')
                        AND (
                            -- Regra de Prioridade: Permissão de Usuário Temporário/Específico prevalece
                            user_perms.permitido = 1
                            OR
                            -- Se não há regra específica do usuário (NULL), verifica a do perfil ATIVO
                            (user_perms.permitido IS NULL AND profile_perms.id_modulo IS NOT NULL)
                        )
                    ORDER BY
                        m.ordem ASC, m.nome ASC;
                ";

                $stmt = $pdo->prepare($sql);
                // Execução: O primeiro ? é o ID do perfil ATIVO (5), o segundo ? é o ID do usuário (20)
                $stmt->execute([$perfilAtivoId, $userId]);
            }

            $allowedModules = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (empty($allowedModules)) {
                return self::getDefaultMenu();
            }

            return self::buildMenuHierarchy($allowedModules);
        } catch (PDOException $e) {
            error_log("Erro ao buscar itens de menu: " . $e->getMessage());
            return self::getDefaultMenu();
        }
    }

    /**
     * Retorna apenas o menu Dashboard para usuários sem permissões.
     */
    private static function getDefaultMenu(): array
    {
        try {
            $pdo = getDbConnection();
            $stmt = $pdo->query("SELECT * FROM modulos WHERE nome = 'Dashboard' AND status = 'liberado'");
            $dashboard = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($dashboard) {
                $dashboard['submenus'] = [];
                return [$dashboard['id'] => $dashboard];
            }
        } catch (PDOException $e) {
            error_log("Erro ao buscar menu padrão: " . $e->getMessage());
        }
        return [];
    }

    /**
     * Organiza uma lista plana de módulos em uma estrutura hierárquica.
     */
    private static function buildMenuHierarchy(array $modules): array
    {
        $menu = [];
        // Primeiro, adiciona todos os menus principais
        foreach ($modules as $module) {
            if ($module['tipo_menu'] === 'menu_principal') {
                $menu[$module['id']] = $module;
                $menu[$module['id']]['submenus'] = [];
            }
        }
        // Depois, aninha os submenus
        foreach ($modules as $module) {
            if ($module['tipo_menu'] === 'submenu_item' && isset($menu[$module['id_modulo_pai']])) {
                $menu[$module['id_modulo_pai']]['submenus'][] = $module;
            }
        }
        return $menu;
    }
}
