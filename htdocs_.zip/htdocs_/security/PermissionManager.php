<?php
class PermissionManager
{
    private static $permissoesCache = null;

    /**
     * Verifica se o usuário logado tem permissão para uma ação específica em um módulo.
     *
     * @param string $acao A ação a ser verificada (ex: 'editar', 'excluir', 'criar').
     * @param int $moduleId O ID do módulo em questão.
     * @return bool
     */
    public static function can(string $acao, int $moduleId): bool
    {
        if (!isset($_SESSION['user_id'])) {
            return false;
        }

        if (isset($_SESSION['perfis']) && in_array(4, $_SESSION['perfis'])) {
            return true;
        }

        if (self::$permissoesCache === null) {
            self::loadPermissionsForUser($_SESSION['user_id']);
        }

        return isset(self::$permissoesCache[$moduleId]) && in_array($acao, self::$permissoesCache[$moduleId]);
    }

    /**
     * Carrega todas as permissões de ação de um usuário e as armazena em cache estático.
     */
    private static function loadPermissionsForUser(int $userId)
    {
        self::$permissoesCache = [];
        try {
            $pdo = getDbConnection();

            // --- PASSO A: Carrega as permissões BASE do(s) perfil(s) do usuário ---

            // A.1: Carrega permissões de VISUALIZAÇÃO do perfil
            $sql_perfil_vis = "
                SELECT DISTINCT pmp.id_modulo
                FROM perfil_modulo_permissao pmp
                JOIN loginperfil lp ON pmp.id_perfil = lp.id_perfil
                WHERE lp.id_login = :userId AND pmp.visualizar = 1
            ";
            $stmt_perfil_vis = $pdo->prepare($sql_perfil_vis);
            $stmt_perfil_vis->execute([':userId' => $userId]);

            foreach ($stmt_perfil_vis->fetchAll(PDO::FETCH_ASSOC) as $row) {
                self::$permissoesCache[$row['id_modulo']][] = 'visualizar';
            }

            // A.2: Carrega permissões de AÇÃO do perfil
            $sql_perfil_acao = "
                SELECT DISTINCT pap.id_modulo, pap.acao
                FROM perfil_acao_permissao pap
                JOIN loginperfil lp ON pap.id_perfil = lp.id_perfil
                WHERE lp.id_login = :userId
            ";
            $stmt_perfil_acao = $pdo->prepare($sql_perfil_acao);
            $stmt_perfil_acao->execute([':userId' => $userId]);

            foreach ($stmt_perfil_acao->fetchAll(PDO::FETCH_ASSOC) as $row) {
                // Evita duplicatas se 'visualizar' for acidentalmente adicionado aqui
                if ($row['acao'] !== 'visualizar' && !in_array($row['acao'], self::$permissoesCache[$row['id_modulo']] ?? [])) {
                    self::$permissoesCache[$row['id_modulo']][] = $row['acao'];
                }
            }

            // --- PASSO B: Carrega e aplica SOBREPOSIÇÕES (overrides) do usuário ---

            // B.1: Sobreposições de VISUALIZAÇÃO
            $sql_user_vis = "
                SELECT id_modulo, permitido
                FROM usuario_modulo_permissao
                WHERE id_usuario = :userId
                  AND (data_inicio_validade IS NULL OR CURDATE() >= data_inicio_validade)
                  AND (data_fim_validade IS NULL OR CURDATE() <= data_fim_validade)
            ";
            $stmt_user_vis = $pdo->prepare($sql_user_vis);
            $stmt_user_vis->execute([':userId' => $userId]);

            foreach ($stmt_user_vis->fetchAll(PDO::FETCH_ASSOC) as $override) {
                $moduleId = $override['id_modulo'];
                if (!isset(self::$permissoesCache[$moduleId])) {
                    self::$permissoesCache[$moduleId] = [];
                }

                // Remove a permissão 'visualizar' antiga para aplicar a regra de sobreposição
                self::$permissoesCache[$moduleId] = array_diff(self::$permissoesCache[$moduleId], ['visualizar']);

                if ($override['permitido'] == 1) { // Regra "Sempre Permitir"
                    self::$permissoesCache[$moduleId][] = 'visualizar';
                }
                // Se for 'negar' (permitido=0 ou Padrão do Perfil com negação), a ação já foi removida e não é adicionada.
                // NOTA: A sua imagem image_a8135c.png mostra uma opção "Padrão do Perfil" que este override pode não estar a tratar.
                // Se a lógica "Padrão do Perfil" for 0, isto está correto.
            }

            // B.2: Sobreposições de AÇÃO
            $sql_user_acao = "
                SELECT id_modulo, acao, permitido
                FROM usuario_acao_permissao
                WHERE id_usuario = :userId
                  AND (data_inicio_validade IS NULL OR CURDATE() >= data_inicio_validade)
                  AND (data_fim_validade IS NULL OR CURDATE() <= data_fim_validade)
            ";
            $stmt_user_acao = $pdo->prepare($sql_user_acao);
            $stmt_user_acao->execute([':userId' => $userId]);

            foreach ($stmt_user_acao->fetchAll(PDO::FETCH_ASSOC) as $override) {
                $moduleId = $override['id_modulo'];
                $action = $override['acao'];

                if (!isset(self::$permissoesCache[$moduleId])) {
                    self::$permissoesCache[$moduleId] = [];
                }

                // Remove a permissão antiga para aplicar a regra de sobreposição
                self::$permissoesCache[$moduleId] = array_diff(self::$permissoesCache[$moduleId], [$action]);

                if ($override['permitido'] == 1) { // Regra "Permitir"
                    self::$permissoesCache[$moduleId][] = $action;
                }
            }
        } catch (PDOException $e) {
            error_log("Erro ao carregar permissões (visualização e ação) para o usuário {$userId}: " . $e->getMessage());
        }
    }
}
